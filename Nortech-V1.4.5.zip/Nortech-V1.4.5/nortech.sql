-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  jeu. 13 déc. 2018 à 07:49
-- Version du serveur :  5.7.21
-- Version de PHP :  5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `nortech`
--

-- --------------------------------------------------------

--
-- Structure de la table `absence`
--

DROP TABLE IF EXISTS `absence`;
CREATE TABLE IF NOT EXISTS `absence` (
  `noAbs` int(11) NOT NULL AUTO_INCREMENT,
  `dateAbsD` date NOT NULL,
  `dateAbsF` date NOT NULL,
  `motif` longtext,
  `justificatif` varchar(250) DEFAULT NULL,
  `nbJPris` int(11) DEFAULT NULL,
  `nbrJA` int(11) DEFAULT NULL,
  `noEmp` int(11) NOT NULL,
  `types` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`noAbs`),
  KEY `Absence_Employe_FK` (`noEmp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `annonce`
--

DROP TABLE IF EXISTS `annonce`;
CREATE TABLE IF NOT EXISTS `annonce` (
  `noAnnonce` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(50) NOT NULL,
  `service` varchar(255) DEFAULT NULL,
  `dateAnnonce` date NOT NULL,
  `ville` varchar(255) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`noAnnonce`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `annonce`
--

INSERT INTO `annonce` (`noAnnonce`, `titre`, `service`, `dateAnnonce`, `ville`, `description`) VALUES
(4, 'DÃ©veloppeur PHP 7', 'Informatique', '2018-11-17', 'Paris', 'Nous recherchons actuellement un dÃ©veloppeur PHP 7 pour un durÃ©e de 7 mois.'),
(21, 'Directeur Controlling Supply Chain H/F', 'Logistique', '2018-11-20', 'Seclin', 'RattachÃ© au Directeur des OpÃ©rations Groupe, vous Ãªtes le garant sur le pÃ©rimÃ¨tre des missions suivantes : - Analyser les rÃ©sultats financiers et la cohÃ©rence des informations Ã©conomiques sur votre pÃ©rimÃ¨tre, - Coordonner les processus budgÃ©taires et le dÃ©veloppement des indicateurs de performance pour la Direction Supply Chain, - Assurer le suivi des projets entamÃ©s dans le cadre de la refonte du schÃ©ma Supply Chain France, - Manager l\'Ã©quipe de ContrÃ´le de Gestion Supply Chain, - Travailler avec l\'ensemble des directions impactÃ©es par ce projet de transformation & refonte. , De formation supÃ©rieure, vous avez au moins 10 d\'expÃ©rience professionnelle en Direction du Controlling en Grand Groupe. Vous Ãªtes bilingue en anglais, vous prÃ©sentez une passion pour les chiffres et pour le Business. Avec un charisme affirmÃ©, vous avez un goÃ»t pour le management, une excellente communication et un bon sens des responsabilitÃ©s et des prioritÃ©s. Vous aimez mener des objectifs ambitieux. Conditions et Avantages N/C'),
(22, 'Approvisionneur (H/F)', 'Logistique', '2018-11-20', 'Seclin', 'Recherche: Approvisionneur (H/F)\r\n\r\nAu sein du service approvisionnement, vos missions seront les suivantes :\r\n* PrÃ©voir les stocks Ã  l\'aide de l\'outil informatique de gestion, en fonction des ventes des magasins\r\n* GÃ©rer les flux de livraisons avec les fournisseurs\r\n* PrÃ©voir l\'approvisionnement de l\'ensemble des points de vente de l\'enseigne\r\n* GÃ©rer le flux de commandes avec l\'entrepÃ´t\r\n* Ã‰laborer des analyses de stocks pour les diffÃ©rents services concernÃ©s\r\n* Prendre en charge la rÃ©solution des litiges de rÃ©ception et de facturation. Vous \r\n        saisissez les retours fournisseurs et suivez leur bonne exÃ©cution.\r\n* Veiller au respect des dÃ©lais et relancer les fournisseurs.'),
(23, 'Assistant logistique (H/F)', 'Logistique', '2018-11-20', 'Seclin', 'Recherche: Assistant logistique (H/F)\r\n\r\nRattachÃ© au responsable entrepÃ´t vos missions seront les suivantes : \r\n*       GÃ©rer le stock sous SAP\r\n*      Classer et archiver les documents\r\n* VÃ©rifier les dossiers administratifs (bons de livraison et de retour, signatures des clients)\r\n* Planifier les expÃ©ditions de produits \r\n* Ã‰tablir les documents de transport pour l\'expÃ©dition des marchandises Ã  partir de SAP\r\n* Assurer le suivi des livraisons\r\n* Organiser les retours de marchandises\r\n* GÃ©rer les litiges transports'),
(24, 'Formateur / Formatrice bureautique (H/F)', 'Formation', '2018-11-21', 'Villeneuve d\'ascq', 'Vous assurez une formation numÃ©rique auprÃ¨s d\'adultes demandeurs d\'emploi en recherche de perfectionnement digital sur le Pack office (Word, Excel, Powerpoint, Outlook, Access..) ainsi qu\'une meilleure connaissance de l\'utilisation d\'internet (Univers windows).Vous prÃ©sentez prÃ©cisÃ©ment les techniques et les logiciels qui seront utiles aux stagiaires dans une logique Â« mÃ©tier Â», basÃ©e sur des tests de niveaux, des Ã©valuations et une pÃ©dagogie pensÃ©e pour optimiser des savoir-faire afin de favoriser leur insertion professionnelle et leur adaptation aux Ã©volutions techniques en vue de l\'obtention du PCIE. IdÃ©alement vous revoyez le CV et la LM dans des exercices dÃ©diÃ©s aux logiciels.\r\n  \r\n Titulaire d\'un titre professionnel de formateur pour adultes ou formateur informatique avec une expÃ©rience professionnelle de deux ans minimum sur les outils bureautiques et le web. Vous savez gÃ©rer un groupe d\'adultes de niveaux hÃ©tÃ©rogÃ¨ne pour les mener au mieux vers la certification. Vous Ãªtes en mesure d\'animer des rÃ©unions d\'information collectives et de sÃ©lectionner les stagiaires motivÃ©s.Rigoureux, rÃ©actif, dynamique, vous possÃ©dez des capacitÃ©s d\'Ã©coute et des capacitÃ©s Ã  fÃ©dÃ©rer un groupe.'),
(25, 'Formateur / Formatrice d\'adultes (H/F) logistique', 'Formation', '2018-11-21', 'Villeneuve d\'ascq', 'Vous aurez pour missions principales la prÃ©paration et l\'animation des actions de formation en salle et en conduite dans le domaine de la logistique :CACESÂ® R389- Titre Professionnel Cariste d\'entrepÃ´t- Titre Professionnel PrÃ©parateur de commandes- Titre Professionnel Agent magasinier\r\n  \r\n Vous possÃ©dez une expÃ©rience professionnelle et une formation en logistiqueVous Ãªtes titulaire du CACESÂ® R389 et vous justifiez d\'une pratique rÃ©guliÃ¨re de la conduite de chariots Ã©lÃ©vateurs des catÃ©gories 1, 3 et 5Vous avez une rÃ©elle appÃ©tence pour l\'enseignement. Vous Ãªtes rigoureux, motivÃ© et possÃ©dez un excellent sens relationnelLe CACESÂ® R386 et/ou CACESÂ® R390 ainsi que la pratique rÃ©guliÃ¨re de la conduite des et/ou de nacelles, et/ou de grues auxiliaires seraient un atout supplÃ©mentaire'),
(26, 'Developpeur Web (H/F)', 'Informatique', '2018-11-21', 'Lille', 'Sous la responsabilitÃ© d\'un Chef de Projet, vous aurez pour mission de rÃ©aliser, documenter et maintenir des applications Web orientÃ©es clients internes et externes.Dans ce cadre, vous devrez :- MaÃ®triser les diverses techniques du dÃ©veloppement WEB (HTML 5, CSS, PHP, Javascript, Rest, JSON, SOAP, XML, Responsive Design, etc)- Avoir de bonnes notions de la configuration et la sÃ©curitÃ© des environnements de production WebProfil recherchÃ© :- BAC + 3 Minimum- ExpÃ©rience significative dans ce domaineImplication, autonomie, rigueur, disponibilitÃ© et un bon relationnel constitueront les clÃ©s de votre intÃ©gration au sein de l\'Ã©quipe existante.Salaire fixe compris entre 30 et 35 KEUR annuels selon expÃ©riencesParticipation aux bÃ©nÃ©fices du groupe BNP ParibasRestaurant d\'entrepriseMutuelle d\'entreprise et prÃ©voyance obligatoiresPoste Ã  pourvoir de suite en CDI Ã  Vineuil (41).Cette offre vous intÃ©resse ? Veuillez postuler en direct. ');

-- --------------------------------------------------------

--
-- Structure de la table `consulter`
--

DROP TABLE IF EXISTS `consulter`;
CREATE TABLE IF NOT EXISTS `consulter` (
  `noAnnonce` int(11) NOT NULL,
  `noEmp` int(11) NOT NULL,
  PRIMARY KEY (`noAnnonce`,`noEmp`),
  KEY `Consulter_Employe_FK` (`noEmp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `employe`
--

DROP TABLE IF EXISTS `employe`;
CREATE TABLE IF NOT EXISTS `employe` (
  `noEmp` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `fonction` varchar(50) NOT NULL,
  `sup` int(11) DEFAULT NULL,
  `tauxH` float NOT NULL,
  `comm` int(11) DEFAULT NULL,
  `naissance` date NOT NULL,
  `tel` varchar(50) NOT NULL,
  `mail` varchar(50) NOT NULL,
  `prime` int(11) DEFAULT NULL,
  `embauche` date NOT NULL,
  `depense` int(11) DEFAULT NULL,
  `noServ` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `adresse` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`noEmp`),
  KEY `k2` (`noServ`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `employe`
--

INSERT INTO `employe` (`noEmp`, `nom`, `prenom`, `fonction`, `sup`, `tauxH`, `comm`, `naissance`, `tel`, `mail`, `prime`, `embauche`, `depense`, `noServ`, `active`, `adresse`) VALUES
(1000, 'LEROY', 'PAUL', 'PRESIDENT', NULL, 38.9, NULL, '1967-10-25', '06.10.00.10.00', 'leroy.paul.1000@nortech.com', NULL, '1987-10-25', NULL, 1, 1, '105 rue Vaugirard, 75006 PARIS'),
(1001, 'DELPIERRE', 'DOROTHEE', 'SECRETAIRE', 1000, 10.2, NULL, '1967-10-25', '06.11.00.11.00', 'delpierre.dorothee.1001@nortech.com', 2049, '1987-10-25', NULL, 1, 1, '2 rue Edouard VII, 75009 PARIS'),
(1003, 'MINET', 'MARC', 'VENDEUR', 1000, 9.88, 17230, '1967-07-25', '06.11.02.11.02', 'minet.marc.1003@nortech.com', NULL, '1987-07-25', NULL, 1, 1, '97 rue Lauriston, 75116 PARIS'),
(1002, 'DUMONT', 'LOUIS', 'VENDEUR', 1000, 9.88, NULL, '1967-10-25', '06.11.01.11.01', 'dumont.louis.1002@nortech.com', 3352, '1987-10-25', NULL, 1, 1, '61 rue Brancion, 75015 PARIS'),
(1005, 'DENIMAL', 'JEROME', 'COMPTABLE', 1000, 11.13, NULL, '1967-10-25', '06.11.05.11.05', 'denimal.jerome.1005@nortech.com', NULL, '1987-10-25', NULL, 1, 1, '64 avenue Marceau, 75008 PARIS'),
(1004, 'NYS', 'ETIENNE', 'TECHNICIEN', NULL, 10.3, NULL, '1967-10-25', '06.11.04.11.04', 'nys.etienne.1004@nortech.com', 2058, '1987-10-25', NULL, 1, 1, '28 Bis rue Corentin Cariou, 75019 PARIS'),
(2001, 'MARTIN', 'JEAN', 'TECHNICIEN', NULL, 10.3, NULL, '1967-06-25', '06.12.01.12.01', 'martin.jean.2001@nortech.com', 3165, '1987-06-25', NULL, 2, 1, '5 rue HÃ´tellerie, 59113 SECLIN'),
(3001, 'GERARD', 'ROBERT', 'VENDEUR', 3000, 9.88, 12430, '1979-04-12', '06.13.01.13.01', 'gerard.robert.3001@nortech.com', NULL, '1999-04-12', NULL, 3, 1, '22 avenue Jean Baptiste Lebas, 59100 ROUBAIX'),
(2000, 'LEMAIRE', 'GUY', 'DIRECTEUR', 1000, 25.67, NULL, '1967-03-11', '06.12.00.12.00', 'lemaire.guy.2000@nortech.com', NULL, '1987-03-11', NULL, 2, 1, '17 rue Roger Bouvry, 59113 SECLIN'),
(2002, 'DUPONT', 'JACQUES', 'TECHNICIEN', 2000, 10.3, NULL, '1968-10-30', '06.12.02.12.02', 'dupont.jacques.2002@nortech.com', 4087, '1988-10-30', NULL, 2, 1, '17 rue Roger Bouvry, 59113 SECLIN'),
(3000, 'LENOIR', 'GERARD', 'DIRECTEUR', 1000, 22.17, 13071, '1967-04-02', '06.13.00.13.00', 'lenoir.gerard.3000@nortech.com', NULL, '1987-04-02', NULL, 3, 1, '110 avenue Nations Unies, 59100 ROUBAIX'),
(3003, 'MASURE', 'EMILE', 'TECHNICIEN', NULL, 10.3, NULL, '1968-06-17', '06.13.03.13.03', 'masure.emile.3003@nortech.com', 3949, '1988-06-17', NULL, 3, 1, '37 boulevard GÃ©nÃ©ral Leclerc, 59100 ROUBAIX'),
(5000, 'DUPONT', 'JEAN', 'DIRECTEUR', 1000, 20.11, NULL, '1967-10-03', '06.15.00.15.00', 'dupont.jean.5000@nortech.com', NULL, '1987-10-03', NULL, 5, 1, '15 rue Molinel, 59800 LILLE'),
(5001, 'DUPIRE', 'PIERRE', 'ANALYSTE', NULL, 16.33, NULL, '1964-10-24', '06.15.01.15.01', 'dupire.pierre.5001@nortech.com', NULL, '1984-10-24', NULL, 5, 1, '66 rue LittrÃ©, 59000 LILLE'),
(5002, 'DURAND', 'BERNARD', 'PROGRAMMEUR', NULL, 13.5, NULL, '1967-07-30', '06.15.02.15.02', 'durand.bernard.5002@nortech.com', 1199, '1987-07-30', NULL, 5, 1, '17 rue Colson, 59800 LILLE'),
(5003, 'DELNATTE', 'LUC', 'PUPITREUR', NULL, 9.88, NULL, '1979-01-15', '06.15.03.15.03', 'delnatte.luc.5003@nortech.com', 1599, '1999-01-15', NULL, 5, 1, '11 place de la Gare, 59800 LILLE'),
(6001, 'CARON', 'ALAIN', 'COMPTABLE', 6000, 23.34, NULL, '1965-09-16', '06.16.01.16.01', 'caron.alain.6001@nortech.com', NULL, '1985-09-16', NULL, 6, 1, '17 quai Wault, 59800 LILLE'),
(6000, 'LAVARE', 'PAUL', 'DIRECTEUR', NULL, 22.9, NULL, '1971-12-13', '06.16.00.16.00', 'lavare.paul.6000@nortech.com', NULL, '1991-12-13', NULL, 6, 1, '75 Bis rue LÃ©on Gambetta, 59000 LILLE'),
(6004, 'HAVET', 'ALAIN', 'VENDEUR', NULL, 9.88, 33415, '1971-01-01', '06.16.04.16.04', 'havet.alain.6004@nortech.com', NULL, '1991-01-01', NULL, 6, 1, '116 rue de l\'HÃ´pital Militaire, 59800 LILLE'),
(6003, 'MOREL', 'ROBERT', 'COMPTABLE', NULL, 23.34, NULL, '1965-07-18', '06.16.03.16.03', 'morel.robert.6003@nortech.com', NULL, '1985-07-18', NULL, 6, 1, '5 rue de la Monnaie, 59800 LILLE'),
(6002, 'DUBOIS', 'JULES', 'VENDEUR', NULL, 9.88, 35535, '1970-12-11', '06.16.02.16.02', 'dubois.jules.6002@nortech.com', NULL, '1990-12-11', NULL, 6, 1, '46 Bis rue de Paris, 59800 LILLE'),
(6005, 'RICHARD', 'JULES', 'COMPTABLE', NULL, 23.7, NULL, '1965-10-22', '06.16.05.16.05', 'richard.jules.6005@nortech.com', NULL, '1985-10-22', NULL, 6, 1, '30 rue Paul Duez, 59800 LILLE'),
(6015, 'DUPREZ', 'JEAN', 'BALAYEUR', 5000, 9.88, NULL, '1978-10-22', '06.16.15.16.15', 'duprez.jean.6015@nortech.com', 5399, '1998-10-22', NULL, 6, 1, '21 rue Barbe a papa, 59800 LILLE'),
(7004, 'HADADI', 'MORAD', 'VENDEUR', NULL, 9.88, 31415, '1995-01-01', '06.17.04.17.04', 'hadadi.morad.7004@nortech.com', NULL, '2015-01-01', NULL, 7, 1, '22 place de la LibertÃ©, 59100 ROUBAIX'),
(7003, 'PIRLO', 'LUCA', 'TECHNICIEN', NULL, 10.3, NULL, '1987-07-18', '06.17.03.17.03', 'pirlo.luca.7003@nortech.com', NULL, '2007-07-18', NULL, 7, 1, '245 boulevard Fourmies, 59100 ROUBAIX'),
(7000, 'ADAMO', 'LAURA', 'DIRECTEUR', NULL, 23.8, NULL, '1983-10-11', '06.17.00.17.00', 'adamo.laura.7000@nortech.com', NULL, '2003-10-11', NULL, 7, 1, '14 avenue Jean Baptiste Lebas, 59100 ROUBAIX'),
(7005, 'COSTA', 'RICARDO', 'SUPERVISEUR', 7000, 17.6, NULL, '1981-10-22', '06.17.05.17.05', 'costa.ricardo.7005@nortech.com', NULL, '2001-10-22', NULL, 7, 1, '22 Grande Rue, 59100 ROUBAIX');

-- --------------------------------------------------------

--
-- Structure de la table `frais`
--

DROP TABLE IF EXISTS `frais`;
CREATE TABLE IF NOT EXISTS `frais` (
  `noFrais` int(11) NOT NULL AUTO_INCREMENT,
  `motif` varchar(50) NOT NULL,
  `montant` float NOT NULL,
  `dateFrais` date NOT NULL,
  `noEmp` int(11) NOT NULL,
  `autreMotif` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`noFrais`),
  KEY `frais_Employe_FK` (`noEmp`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `historique`
--

DROP TABLE IF EXISTS `historique`;
CREATE TABLE IF NOT EXISTS `historique` (
  `dateConnection` datetime DEFAULT CURRENT_TIMESTAMP,
  `adresseIP` varchar(50) DEFAULT NULL,
  `poste` varchar(50) DEFAULT NULL,
  `identifiant` varchar(50) DEFAULT NULL,
  KEY `identifiant` (`identifiant`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `historique`
--

INSERT INTO `historique` (`dateConnection`, `adresseIP`, `poste`, `identifiant`) VALUES
('2018-12-13 08:41:08', '10.115.57.124', 'STA6017736.exchange.ad.afpanet', 'leroy.paul.1000@nortech.com');

-- --------------------------------------------------------

--
-- Structure de la table `service`
--

DROP TABLE IF EXISTS `service`;
CREATE TABLE IF NOT EXISTS `service` (
  `noServ` int(11) NOT NULL,
  `service` varchar(50) NOT NULL,
  `ville` varchar(50) NOT NULL,
  PRIMARY KEY (`noServ`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `service`
--

INSERT INTO `service` (`noServ`, `service`, `ville`) VALUES
(1, 'DIRECTION', 'PARIS'),
(2, 'LOGISTIQUE', 'SECLIN'),
(3, 'VENTES', 'ROUBAIX'),
(4, 'FORMATION', 'VILLENEUVE D\'ASCQ'),
(5, 'INFORMATIQUE', 'LILLE'),
(6, 'COMPTABILITE', 'LILLE'),
(7, 'TECHNIQUE', 'ROUBAIX'),
(8, 'RH', 'PARIS');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `identifiant` varchar(50) NOT NULL,
  `motPasse` varchar(50) NOT NULL,
  `droits` varchar(10) NOT NULL,
  `noEmp` int(11) DEFAULT NULL,
  `changeMdp` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`identifiant`),
  KEY `Utilisateur_Employe0_FK` (`noEmp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`identifiant`, `motPasse`, `droits`, `noEmp`, `changeMdp`) VALUES
('minet.marc.1003@nortech.com', '147', '3', 1003, NULL),
('hadadi.morad.7004@nortech.com', '143', '4', 7004, NULL),
('pirlo.luca.7003@nortech.com', '133', '4', 7003, NULL),
('duprez.jean.6015@nortech.com', '132', '4', 6015, NULL),
('richard.jules.6005@nortech.com', '131', '4', 6005, NULL),
('havet.alain.6004@nortech.com', '136', '4', 6004, NULL),
('morel.robert.6003@nortech.com', '135', '4', 6003, NULL),
('dubois.jules.6002@nortech.com', '134', '4', 6002, NULL),
('caron.alain.6001@nortech.com', '139', '4', 6001, NULL),
('lavare.paul.6000@nortech.com', '138', '4', 6000, NULL),
('delnatte.luc.5003@nortech.com', '137', '4', 5003, NULL),
('durand.bernard.5002@nortech.com', '127', '4', 5002, NULL),
('dupire.pierre.5001@nortech.com', '128', '4', 5001, NULL),
('dupont.jean.5000@nortech.com', '129', '4', 5000, NULL),
('masure.emile.3003@nortech.com', '124', '3', 3003, NULL),
('gerard.robert.3001@nortech.com', '125', '3', 3001, NULL),
('lenoir.gerard.3000@nortech.com', '126', '3', 3000, NULL),
('dupont.jacques.2002@nortech.com', '987', '2', 2002, NULL),
('martin.jean.2001@nortech.com', '654', '2', 2001, NULL),
('lemaire.guy.2000@nortech.com', '321', '4', 2000, NULL),
('denimal.jerome.1005@nortech.com', '369', '3', 1005, NULL),
('nys.etienne.1004@nortech.com', '258', '3', 1004, NULL),
('dumont.louis.1002@nortech.com', '789', '3', 1002, NULL),
('delpierre.dorothee.1001@nortech.com', '456', '2', 1001, NULL),
('leroy.paul.1000@nortech.com', '123', '1', 1000, NULL),
('costa.ricardo.7005@nortech.com', 'NORTECH', '0', 7005, NULL),
('adamo.laura.7000@nortech.com', 'Bonjour', '0', 7000, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
