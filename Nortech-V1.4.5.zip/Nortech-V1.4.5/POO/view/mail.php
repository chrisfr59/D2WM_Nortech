<?php $nav_en_cours = 'employe'; ?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link rel="stylesheet" href="css/main.css">
    <title>Site Nortech</title>
</head>

<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
include('header.php');
$_SESSION=array_merge($_SESSION,$_POST);
if(!empty($_GET)){
    if($_GET['action']=='mail'){
        $_SESSION['mail'][0]=$_GET['mail'];
        $_SESSION['Envoi']=true;
    }
    else{
        $_SESSION['mail'][0]=$_GET['mail'];
        $_SESSION['CV']=true;
    }
}

if(isset($_SESSION['Envoi'])){
    if(empty($_SESSION['mail'])){
        echo "<script type='text/javascript'>document.location.replace('employe.php');
        alert('Veuillez cochez une case.');
        </script>";
    }
    else{
        $liste='';
        $destinataire='';
        $i=0;
        while($i<count($_SESSION['mail'])){
            $temp=explode('.',$_SESSION['mail'][$i]);
            $liste=$liste.', '.$temp[0].' '.$temp[1];
            $destinataire=$destinataire.', '.$_SESSION['mail'][$i];
            $i++;
        }
        $liste=substr($liste,1);
        $destinataire=substr($destinataire,1);

        if(isset($_SESSION['sujet'])){
            $sujet=$_SESSION['sujet'];
            $message=wordwrap($_SESSION['message'],70,"\n", false);
            mail($destinataire, $sujet, $message);
            echo "<script type='text/javascript'>document.location.replace('employe.php');
                alert('Message Envoyé !');
                </script>";
        }
        ?>

        <body>
            <div class=row>
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <form name="mail" method="post" action="">
                        <fieldset id="section">
                            <p class="destinataire"> Destinataire : <?php echo $liste;?></p><br><br>
                            <legend>Mail</legend>
                            <label for="sujet">Sujet : </label><br><br>
                            <input class="input" type="text" name="sujet" id="sujetMail" required><br><br>

                            <label for="message">Message : </label><br><br>
                            <textarea name="message" id="messageMail" required></textarea><br><br>
                            <br><br><br><br><br><br><br><br><br>
                            <input type="submit" class="submitMail" value="Envoyer">
                            <br>
                        </fieldset>
                    </form>
                </div>
                <div class="col_md-2"></div>
            </div><br>
        </body>

        <?php

    }
}
else if(isset($_SESSION['CV'])){
    if(empty($_SESSION['mail'])){
        echo "<script type='text/javascript'>document.location.replace('employe.php');
        alert('Veuillez cochez une case.');
        </script>";
    }
    else{
       $i=0;
        while($i<count($_SESSION['mail'])){

            $sql='select noEmp, nom, prenom from nortech.employe where mail like "'.$_SESSION['mail'][$i].'"';
            //Préparation de la requête SQL en utilisant la variable $connexion
            $req=$connexion->prepare($sql);
            //execuction de la requête avec enregistrement des résultats dans la variable $reponse
            //(boolean qui prend deux valeurs : 1 pour execute=ok et 0 pour execute=ko)
            $reponse=$req->execute(array());

            $resultat=$req->fetch();

            $fichier= '../../CV/'.$resultat['noEmp'].'_'.$resultat['nom'].'_'.$resultat['prenom'].'.pdf';

            echo '<iframe src="'.$fichier.'" width="600" height="800" align="middle"></iframe>';
            
            $i++;
        }
    }
}

?>

</html>