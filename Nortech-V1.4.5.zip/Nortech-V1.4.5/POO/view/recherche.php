<?php 
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
$nav_en_cours = 'offre_emploi';
include('header.php');?>
<link href="offre.css" rel="stylesheet">


<div class=formulaire>
    <div class='recherche'>
        <form method="GET" action="recherche.php">
            <h3>Rechercher une annonce</h3><br>
            <input type="search" name="terme" placeholder="Saisir le titre ou la ville" /><br><br>
            <input id="search" type="submit" name="s" value="Rechercher" required />
            <input id="effacer" type="reset" value="Effacer" />
        </form>
    </div><br>
    <a href="ajouter_annonce.php?section=offre"><input id="ajouter" type="button" value="Ajouter une offre d'emploi"></a><br><br>
</div>
<?php


 $connexion->query("SET NAMES UTF-8");
 
 if (isset($_GET["s"]) AND $_GET["s"] == "Rechercher")
 {
        $_GET["terme"] = htmlentities($_GET["terme"]); //htmlspecialchars
        
        $terme = $_GET["terme"];
        $terme = trim($terme);
        $terme = strip_tags($terme);              
 
if (isset($terme)){
     

        $terme = strtolower($terme);
        $mots = explode(' ',$terme);//En separre lexpression en mots cles
    foreach($mots as $mot) {   
        $select_terme = $connexion->prepare('SELECT * from nortech.annonce where titre like "%'.$mot.'%" or description like "%'.$mot.'%" or ville like "%'.$mot.'%" order by dateAnnonce');
        $select_terme->execute(array("%".$terme."%","%".$terme."%"));
    }}
}else{
        $message = "Vous devez entrer votre requete dans la barre de recherche";
}
?>
<!DOCTYPE html>

<head>
    <link href="css/emploi.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
</head>
<html>

<body>
    <?php
  if(isset($terme)){

  while($terme_trouve = $select_terme->fetch()){
   

    if($terme){
        echo "<div class='offre'><h1 class='titre'>".preg_replace('#('.str_replace(' ','|',preg_quote($terme)).')#i', '<mark><u><strong>$1</strong></u></mark>', $terme_trouve['titre'])."</h1>";
        //echo "<div><h2>".$terme_trouve['titre']."</h2>";
        echo "<h4>Service :  ".$terme_trouve['service']."</h4>";
        echo "<h4>Date :  ".$terme_trouve['dateAnnonce']."</h4>";
        echo "<h4>Ville:  ".$terme_trouve['ville']."</h4>";
        echo '<h4 class="entreprise"> Entreprise : </h4>
           <td >
           Rejoignez les équipes de Nortech pour concevoir et intégrer les solutions innovantes de demain. <br><br>
           Nous accompagnons au quotidien les entreprises et les organisations dans leurs enjeux de transformation industrielle et digitale.<br> Notre ambition : le faire avec vous.

            Parce que l’humain est au cœur de notre stratégie, nous pouvons offrir à chacun un cadre professionnel stimulant, <br>collaboratif et ouvert sur l\'avenir.<br><br>

            Parce que votre talent mérite notre engagement, Créons ensemble la différence !
            </td><br><br>';
        //echo "<p> ".$terme_trouve['description']."</p>";
        echo preg_replace('#('.str_replace(' ','|',preg_quote($terme)).')#i', '<mark><u><strong>$1</strong></u></mark>', $terme_trouve['description']);//On surligne les mots cles de la recherche
        echo '<br><br><a href="postuler.php?section=Offre_d_emploi"><input id="postuler" type="button" value="Postuler"></a><br><br></div>';
    }else{
        echo "<script type='text/javascript'>document.location.replace('redirection.php?section=offreemploi');
                alert('Veuillez saisir quelque chose dans la barre de recherche !');
                </script>";
  }
}
  $select_terme->closeCursor();
}
  
 
   ?>




    <?php include('footer.php');?>