<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
$nav_en_cours = 'service';
include('header.php');

$sql='SELECT s.noServ,s.service,s.ville, SUM(ifnull(f.montant,0)) FROM nortech.service s left JOIN nortech.employe e ON s.noServ=e.noServ 
left join nortech.frais f ON f.noEmp=e.noEmp where s.noServ is not null GROUP BY s.noServ';

// préparation de la requête SQL en utilisant la variable $connexion
$req=$connexion->prepare($sql);
//execution de la requête avec enregistrement des résultats dans la variable $reponse (boolean qui prend deux valeurs 1 pour execute=ok et 0 pour execute=ko)
$reponse=$req->execute(array());

?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
            <!--Main Stylesheet-->
            <link href="css/style.css" rel="stylesheet">
        <!--Responsive Framework-->
        <link href="css/responsive.css" rel="stylesheet">
        <link href="css/main.css" rel="stylesheet">
</head>
<article>
	<div style="text-align: center;width:100%; height: 60px;background-color:#4DA91C;color: white; margin:2% auto; padding:1.5rem ; ">
	<p style="font-size: 20px;"><b>Liste des <?php echo $mot;?></b></p>
    </div>
   
    <div class="row">
        <div class="col-xs-12 col-md-2"></div>
        <div class="col-xs-12 col-md-8">
        <div class=tabServ>
    	<table class="table">
    		<thead>
    			<tr>
    			<th >N°</th><th >Service</th><th>Ville</th><th >Dépenses</th><th> Mise à jour </th>
    			</tr>
    		</thead>
    		<tbody>
    	<?php
    	//while($resultat=$req->fetch()){  
            
            while ($resultat=$req->fetch()) {
                # code...
            
            //echo 'La somme de  dépenses de '.$resulta['noServ'].' est de '.$resulta['sum(ifnull(f.montant,0))'].' €.';   
    	echo '<tr>';
        echo '<td>'.$resultat['noServ'].'</td><td><div id="msg" onmouseover="afficher(infos[2]);" onmouseout="masquer();">'.$resultat['service'].'</div></td><td>'.$resultat['ville'].'</td>
        <td>'.$resultat['SUM(ifnull(f.montant,0))'].' €'.'</td><td><a class="buttonEmpTab"  href="update_service.php?section=service&numServ='.$resultat['noServ'].'">Modifier</a></td>';
    	echo '</tr>';
            }    
        ?>
        </tbody>
        </table>

        </div>
        </div>
        <div class="col-xs-12 col-md-2"></div>
        </div>
    </div>
    <div class="listeR">
    <?php
    $sql='SELECT s.noServ,s.service,s.ville, SUM(ifnull(f.montant,0)) FROM nortech.service s left JOIN nortech.employe e ON s.noServ=e.noServ 
    left join nortech.frais f ON f.noEmp=e.noEmp where s.noserv is not null GROUP BY s.noServ';
    $req=$connexion->prepare($sql);
    $reponse=$req->execute(array());
    while ($resultat=$req->fetch()) {
        echo '<li class="listeServ"><p> <b>- N° Service :</b> '.$resultat['noServ'].'<br>'.' - Service : '.$resultat['service'].'<br>'.' - Ville : '
        .$resultat['ville'].'<br>'.'- Dépenses :' .$resultat['SUM(ifnull(f.montant,0))']. '€'.'<br><br>'.'<a class="buttonEmpTab" href="update.php?section=service&numServ='.$resultat['noServ'].'">Modifier</a>'.'<br>';
    }
    ?>
    </div>
<div style="text-align: center;width:100%; height: 60px;background-color:#4DA91C;color: white; margin:2% auto; padding:1.5rem ; ">
	<p style="font-size:20px;"> <b> Ajouter des <?php echo $mot;?> </b> </p>
</div>


<div class="row" >
    <div class="col-xs-12 col-md-2"></div>
    <div class="col-xs-12 col-md-8">
 <div class='form-group' >
    <fieldset style="background: rgba(255, 255, 255, 0.45); padding:2rem;">
        
        <form name="add_service" method="POST" action="../controller/traitement.php?section=service&action=ajouter" >
            <div class="row">
                <div class="col-xs-12 col-md-2"></div>
                <div class="col-xs-12 col-md-4">
                    <label for="no_serv">N° Service </label>
                </div>
                <div class="col-xs-12 col-md-4">
                    <input type="text" name="no_serv" class="form-control" required>
                </div>
                <div class="col-xs-12 col-md-2"></div>
            </div><br>
            <div class="row">
                <div class="col-xs-12 col-md-2"></div>
                <div class="col-xs-12 col-md-4">
                    <label for="service">Service </label>
                </div>
                <div class="col-xs-12 col-md-4">
                    <input type="text" name="service" class="form-control" required>
                </div>
                <div class="col-xs-12 col-md-2"></div>
            </div><br>
            <div class="row">
                <div class="col-xs-12 col-md-2"></div>
                <div class="col-xs-12 col-md-4">
                    <label for="ville"> Ville </label>
                </div>
                <div class="col-xs-12 col-md-4">
                    <input type="text" name="ville" class="form-control" required>
                </div>
                <div class="col-xs-12 col-md-2"></div>
            </div><br>

            <div class="row">
                <div class="col-xs-12 col-md-6"></div>
                <div class="col-xs-12 col-md-2" style=" padding:0.5rem;">
                    <input type="submit" class="btn btn-success btn-lg" value="Envoyer">
                </div>
                <div class="col-xs-12 col-md-2" style=" padding:0.5rem;">
                    <input type="reset" class="btn btn-success btn-lg" value="Effacer"><br>
                </div>
                <div class="col-xs-12 col-md-2"></div>

            </div>
        </form>
    </fieldset>
    </div>
    </div>
    <div class="col-xs-12 col-md-12"></div>
    </div>
    
    <div style="text-align: center;width:100%; height: 60px;background-color:#4DA91C;color: white; margin:2% auto; padding:1.5rem ; ">
	<p style="font-size: 20px;"><b>Supprimer des <?php echo $mot;?></b></p>
	</div>
    <div class="row">
        <div class="col-xs-12 col-md-2"></div>
        <div class="col-xs-12 col-md-8">   
    	   <div class='formulaire_post'>

                <fieldset style="background: rgba(255, 255, 255, 0.45); padding:1.6rem; "><br>
           
                    <form name="supprimer_user" method="POST" action="../controller/traitement.php?section=service&action=supprimer">
                        <div class="row" style="padding:1.6rem;">
                            <div class="col-xs-12 col-md-2"></div>
                            <div class="col-xs-12 col-md-4">
                                <label for="no_serv">N° Service </label>
                            </div>
                            <div class="col-xs-12 col-md-4">
                                <input type="text" name="no_serv" class="form-control" required>
                            </div>
                            <div class="col-xs-12 col-md-2"></div>
                        </div>
                        <div class="row" style="padding:1.6rem;">
                            <div class="col-xs-12 col-md-6"></div>
                            <div class="col-xs-12 col-md-2" style=" padding:0.5rem;">
                                <input type="submit" class="btn btn-danger btn-lg " class="button" value="Supprimer">
                            </div>
                            <div class="col-xs-12 col-md-2" style=" padding:0.5rem;">
                                <input type="reset" class="btn btn-success btn-lg" class="button" value="Effacer">
                            </div>
                            <div class="col-xs-12 col-md-2"></div>
                        </div>
                    </form>
             </fieldset>

            </div>
        </div>
        <div class="col-xs-12 col-md-2"></div>
    </div>
</article>
<?php
include('footer.php');
?>