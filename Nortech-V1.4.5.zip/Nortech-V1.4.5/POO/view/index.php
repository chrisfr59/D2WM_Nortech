
<?php
        $nav_en_cours = 'index';
        include('header_Ext.php');
?>

<!--Start of slider section-->
<section id="slider">
    <div id="carousel-example-generic" class="carousel slide carousel-fade" data-ride="carousel" data-interval="3000">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
        </ol>

        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <div class="slider_overlay">
                    <img src="img/img1.jpg" alt="...">
                    <div class="carousel-caption">
                        <div class="slider_text">
                            <h3></h3>
                            <h2><span class="letter">Nor</span>tech</h2>
                            <p>Une entreprise au service des énergies renouvelables</p>
                            <!--<a href="" class="custom_btn">En savoir plus</a>-->
                        </div>
                    </div>
                </div>
            </div>
            <!--End of item With Active-->
            <div class="item">
                <div class="slider_overlay">
                    <img src="img/img2.jpg" alt="...">
                    <div class="carousel-caption">
                        <div class="slider_text">
                            <h3></h3>
                            <h2><span class="letter">Nor</span>tech</h2>
                            <p>Des bureaux éco-responsables</p>
                            <!--<a href="" class="custom_btn">En savoir plus</a>-->
                            </div>
                    </div>
                </div>
            </div>
            <!--End of Item-->
            <div class="item">
                <div class="slider_overlay">
                    <img src="img/img4.jpg" alt="...">
                    <div class="carousel-caption">
                        <div class="slider_text">
                            <h3></h3>
                            <h2><span class="letter">Nor</span>tech</h2>
                            <p>Des professionnels à votre écoute</p>
                            <!--<a href="" class="custom_btn">En savoir plus</a>-->
                            </div>
                    </div>
                </div>
            </div>
            <!--End of item-->
        </div>
        <!--End of Carousel Inner-->
    </div>
</section>
<!--end of slider section-->
<!--Start of welcome section-->
<section id="reseaux">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="col-md-6">
                    <script>
                        window.fbAsyncInit = function() {
                                  FB.init({
                                    appId            : 'your-app-id',
                                    autoLogAppEvents : true,
                                    xfbml            : true,
                                    version          : 'v3.2'
                                  });
                                };
                                
                                (function(d, s, id){
                                   var js, fjs = d.getElementsByTagName(s)[0];
                                   if (d.getElementById(id)) {return;}
                                   js = d.createElement(s); js.id = id;
                                   js.src = "https://connect.facebook.net/en_US/sdk.js";
                                   fjs.parentNode.insertBefore(js, fjs);
                                 }(document, 'script', 'facebook-jssdk'));
                    </script>
                    <div class="fb-page" data-href="https://www.facebook.com/Nortech-209757559924419" data-tabs="timeline"
                        data-height="400" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false"
                        data-show-facepile="true">
                        <blockquote cite="https://www.facebook.com/facebook" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/facebook">Facebook</a></blockquote>
                    </div>
            
                </div>
                <div class="col-md-6">
                    <script>
                        window.fbAsyncInit = function() {
                                  FB.init({
                                    appId            : 'your-app-id',
                                    autoLogAppEvents : true,
                                    xfbml            : true,
                                    version          : 'v3.2'
                                  });
                                };
                                
                                (function(d, s, id){
                                   var js, fjs = d.getElementsByTagName(s)[0];
                                   if (d.getElementById(id)) {return;}
                                   js = d.createElement(s); js.id = id;
                                   js.src = "https://connect.facebook.net/en_US/sdk.js";
                                   fjs.parentNode.insertBefore(js, fjs);
                                 }(document, 'script', 'facebook-jssdk'));
                                </script>
                    <div class="fb-page" data-href="https://www.facebook.com/afpa.centreroubaix" data-height="400"
                        data-tabs="timeline" data-small-header="false" data-adapt-container-width="true"
                        data-hide-cover="false" data-show-facepile="true">
                        <blockquote cite="https://www.facebook.com/facebook" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/facebook">Facebook</a></blockquote>
                    </div>
                </div>
            </div>
        </div>
</section>
<!--End of row-->

<!--Start of contact-->
<section id="contact">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="contact_area text-center">
                            <h3>Contact</h3>
                            <p>Pour toute question ou demande de rendez-vous n'hésitez pas à nous contacter</p>
                        </div>
                    </div>
                </div>
                <!--End of row-->
                <div class="row">
                    <div class="col-md-6">
                        <div class="office">
                            <div class="title">
                                <h4><span class="letter">NOR</span>TECH</h4>
                            </div>
                            <div class="office_location">
                                <div class="address">
                                    <i class="fa fa-map-marker">41-43 Rue du Faubourg Saint-Honoré
                                        75008 Paris<br></i>
                                </div>
                                <div class="phone">
                                    <i class="fa fa-phone"><a href="tel:+311-555-2368">+33 1 02 03 04 05</a></i>
                                </div>
                                <div class="email">
                                    <i class="fa fa-envelope"><a href="mailto:nortech.com">contact@nortech.com</a></i>
                                </div>
                                <div id="map"> <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2624.3932532587455!2d2.316534616009747!3d48.86977937928861!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66fcc3650cde9%3A0xaab4ba922f05c7de!2s43-41+Rue+du+Faubourg+Saint-Honor%C3%A9%2C+75008+Paris!5e0!3m2!1sfr!2sfr!4v1542629924810"
                                        width="300" height="300" frameborder="0" style="border:0" allowfullscreen></iframe></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6" id="message">
                        <div class="msg">
                            <div class="msg_title">
                                <h5>Envoyer un message</h5>
                            </div>
                            <div class="form_area">
                                <!-- CONTACT FORM -->
                                <div class="contact-form wow fadeIn animated" data-wow-offset="10" data-wow-duration="1.5s">
                                    <div id="message"></div>
                                    <form action="../controller/traitementEmail.php" method="POST" class="form-horizontal contact-1" role="form"
                                        name="contactform" id="contactform">
                                        <div class="form-group">
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="name" id="name"
                                                    placeholder="Nom">
                                            </div>
                                            <div class="col-sm-6">
                                                <input type="text" class="form-control" name="email" id="email"
                                                    placeholder="Email"  required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="col-sm-12">
                                                <input type="subject" class="form-control" name="objet" id="subject" placeholder="Sujet" required>
                                                <div class="text_area">
                                                    <textarea name="message" id="msg" class="form-control" cols="30"
                                                        rows="8" placeholder="Message" required></textarea>
                                                </div>
                                                <button type="submit" name='envoi' class="btn custom-btn" data-loading-text="Loading...">Envoyer</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--End of col-md-6-->
                </div>
                <!--End of row-->
            </div>
            <!--End of container-->
        </section>
        <!--End of contact-->

        <!--Start of footer-->
        <?php
        include('footer.php');
        ?>
        <!--End of footer-->

        </body>

</html>