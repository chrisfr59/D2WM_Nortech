<?php $nav_en_cours = 'user'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/perso.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Document</title>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

<!--Fontawesom-->
<link rel="stylesheet" href="css/font-awesome.min.css">

<!--Animated CSS-->
<link rel="stylesheet" type="text/css" href="css/animate.min.css">

<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!--Bootstrap Carousel-->
<link type="text/css" rel="stylesheet" href="css/carousel.css" />

<link rel="stylesheet" href="css/isotope/style.css">

<!--Main Stylesheet-->
<link href="css/style.css" rel="stylesheet">
<!--Responsive Framework-->
<link href="css/responsive.css" rel="stylesheet">

<link rel="stylesheet" href="css/cssUser.css">



</head>

<body>
<?php 
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
include('header.php');
?>
<div class="container">

<?php
function rechercher1($name){
    global $connexion;
    $existant= false;
    $req1 = $connexion->prepare("SELECT i.*,e.nom,e.prenom FROM utilisateur i,employe e where i.identifiant=e.mail AND e.nom='$name' AND e.active=1");
    $reponse1=$req1->execute(array());
    if (isset($reponse1)){
        while($result=$req1->fetch()){
            if ($result['nom'] == $name)
            {
                echo '<div class="container">';
                echo '<table class="table table-striped">';
                echo '<thead>';
                echo'<tr>';
                echo '<th scope="col">Identifiant</th>';

                echo '<th scope="col">Nom</th>';
                echo '<th scope="col">Prenom</th>';
                echo '<th scope="col">Droits</th>';
                echo '<th scope="col">Num employe</th>';
                echo '<th scope="col">Historique</th>';
         
                echo '</tr>';
                echo '</thead>';
                echo' <tbody>';
                echo '<tr>';
                echo '<td data-label="identifiant">'.$result['identifiant'].'</td>';

                echo '<td data-label="nom">'.$result['nom'].'</td>';
                echo '<td data-label="prenom">'.$result['prenom'].'</td>';
                echo '<td data-label="droits">'.$result['droits'].'</td>';
                echo '<td data-label="noEmp">'.$result['noEmp'].'</td>';
                echo '<td><button class="btn btn-success  my-1" ><a href="historique.php?section=user&id='.$result['identifiant'].'">Historique</a></button></td>';
                
                echo '</tr>';
                echo '</tbody>';
                echo '</table>';
                echo'</div>';
                $existant=true;
            }        
        }
    } 
            
    if ($existant==false){
        echo"<script type='text/javascript'>document.location.replace('user.php');
            alert('Utilisateur inexistant!!');</script>";
    }
}
         
?>
<form class="border border-light p-5" method="POST">
	<h3 class="h4 mb-4">Rechercher un utilisateur</h3>
	<input type="text" id="defaultLoginFormEmail" class="form-control mb-4" placeholder="Nom de l'utilisateur" name="recherche" required>
    
    
    <input class="btn btn-primary btn-xs" type="submit" name="submit" value="Rechercher" />
    
	<!-- -->
	</form>
<?php
//convertir le resultat de la recherche qq soit en maj mins ou les 2
@$_POST["recherche"]=strtoupper($_POST["recherche"]);
   if(isset($_POST["submit"])){
        $recherche=$_POST["recherche"];
        rechercher1($recherche);
       }
    ?>
<section id="section1">
    <h1>Liste des utilisateurs </h1>


    
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Identifiant</th>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">Droits</th>
      <th scope="col">Num employe</th>
      <th scope="col">Historique</th>
    </tr>
  </thead>
  <tbody>
  <?php
 $sql="SELECT i.*,e.nom,e.prenom,e.noEmp FROM utilisateur i,employe e  where i.noEmp=e.noEmp AND e.active=1 order by e.noEmp";
 //preparation de la rqt sql on utilisant la variable $connexion
 $req=$connexion->prepare($sql);
 //execution de la rqt avec eregistrement de resulat de la variable $reponse
 $reponse=$req->execute(array());
 while($result=$req->fetch()){
 echo '<tr>';

 echo '<td data-label="identifiant">'.$result['identifiant'].'</td>';
 echo '<td data-label="nom">'.$result['nom'].'</td>';
 echo '<td data-label="prenom">'.$result['prenom'].'</td>';
 echo '<td data-label="droits">'.$result['droits'].'</td>';
 echo '<td data-label="noEmp">'.$result['noEmp'].'</td>';
 echo '<td><button class="btn btn-success  my-1" ><a href="historique.php?section=user&id='.$result['identifiant'].'">Historique</a></button></td>'; 
 echo '</tr>';
};
?>
    
</tbody>
</table>
</section>
</div>

<?php
include('footer.php');
?>


<!--Bootstrap-->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>