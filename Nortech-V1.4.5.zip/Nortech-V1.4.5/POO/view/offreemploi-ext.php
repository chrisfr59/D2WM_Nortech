<?php $nav_en_cours = 'offreemploi-ext' ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <title>Nortech</title>

    <!--    Google Fonts-->
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

    <!--Fontawesom-->
    <link rel="stylesheet" href="css/font-awesome.min.css">

    <!--Animated CSS-->
    <link rel="stylesheet" type="text/css" href="css/animate.min.css">


    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!--Bootstrap Carousel-->
    <link type="text/css" rel="stylesheet" href="css/carousel.css" />

    <link rel="stylesheet" href="css/isotope/style.css">

    <!--Main Stylesheet-->
    <link href="css/style.css" rel="stylesheet">
    <!--Responsive Framework-->
    <link href="css/responsive.css" rel="stylesheet">
    <link href="css/emploi.css" rel="stylesheet">


    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->



    <title>Document</title>
</head>


<body>

    <body data-spy="scroll" data-target="#header">
        <?php
            include('header_Ext.php');
        ?>




        <div class=formulaire>

        <div class='recherche'>
            
        <form method ="GET" action="recherche-ext.php"> 
            <h3>Rechercher une annonce</h3>                                 
            <input type="search" name="terme" placeholder="Saisir le titre ou la ville"/><br>                                  
            <input id="search" type= "submit" name="s" value="Rechercher" required/> 
            <input id="effacer" type="reset" value="Effacer" />                         
        </form>
        </div><br><br>
        
    </div>
        <?php
    $connexion = new PDO('mysql:host=localhost;dbname=nortech','root','');
      $sql='SELECT * FROM nortech.annonce';
      // préparation de la requête SQL en utilisant la variable $connexion
      $req=$connexion->prepare($sql);
      //execution de la requête avec enregistrement des résultats dans la variable $reponse (boolean qui prend deux valeurs 1 pour execute=ok et 0 pour execute=ko)
      $reponse=$req->execute(array());
        
        $nume=$reponse+1;
        $annonce='annonce';
        $numannonce=1;
        while($resultat=$req->fetch()){
            echo '<div class="offre"';
            echo '<tr>';
            echo '<td ><h5>Offre N° '.$resultat['noAnnonce'].'</h5><h2 class="titre">'.$resultat['titre'].'</h2><h5>Service : </h5>'.$resultat['service'].'</td><br>
            <h5 class="date">Date :</h5> 
            <td class="date">'.$resultat['dateAnnonce'].'</td><br>
            <h5 class="ville">Ville :</h5>
            <td class="ville">'.$resultat['ville'].'</td><br>
           <h5 class="entreprise"> Entreprise : </h5>
           <td ><div>
           Rejoignez les équipes de Nortech pour concevoir et intégrer les solutions innovantes de demain. <br><br>
           Nous accompagnons au quotidien les entreprises et les organisations dans leurs enjeux de transformation industrielle et digitale.<br> Notre ambition : le faire avec vous.

Parce que l’humain est au cœur de notre stratégie, nous pouvons offrir à chacun un cadre professionnel stimulant, <br>collaboratif et ouvert sur l\'avenir.<br><br>

Parce que votre talent mérite notre engagement, Créons ensemble la différence !
       </div></td><br><br>';
            
       echo '<button id="plus" title="Afficher le div" onclick="afficher_div_masque(',$numannonce,')" style="text-align: center; font-weight: bold;">Plus d\'infos</button>
       <div id="',$numannonce,'"style="display:none;"><br> ';
            echo '<td><br><h5 class="entreprise">Description : </h5>',$resultat['description'],'</td></div>';
            echo '</tr><br><br>';
            echo '<a href="postuler_ext.php?section=Offre_d_emploi"><input id="postuler" type="button" value="Postuler"></a>';
            echo '</div><br>';
            $numannonce++;
        }
        include('footer.php');
    ?>


        <!--/.footer-->
        <script type="text/javascript" src="js/nortechcommon.js"></script>
    </body>

</html>