<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/employe.css">
    <title>update</title>
</head>
<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
$nav_en_cours ='employe';
include('header.php');
echo '<br /><br />';
if( !isset ($_GET['id'])){//info en cas d'échec
    echo "<script type='text/javascript'>document.location.replace('employe.php');
       alert('id non trouvé!');
        </script>";
}

//requete sql
$req="SELECT e.nom,e.prenom,e.adresse, e.fonction,e.sup,e.embauche,e.tauxH,e.comm,e.noServ,s.service,e.naissance,e.tel,
e.mail,e.prime from nortech.employe e, nortech.service s where e.noServ=s.noServ and noEmp='{$_GET['id']}'";
//connection bdd
$test=$connexion->query($req);

$sql3="select noServ, service from service";
$req3=$connexion->query($sql3);

$sql4="select distinct fonction from employe";
$req4=$connexion->query($sql4);

$sql="select noEmp from nortech.employe";
$req2=$connexion->query($sql);
$tabnoEmp=array();
while($reponse=$req2->fetch()){
    array_push($tabnoEmp, $reponse['noEmp']);
}

$key=array_search($_GET['id'], $tabnoEmp);

if(gettype($key)=='boolean'){
    echo "<script type='text/javascript'>document.location.replace('employe.php');
       alert('L\'employé sélectionné n\'existe pas!');
        </script>";
}

$resultat=$test->fetch();//résultat et affichage du nom
$_SESSION['nomUp']=$resultat['nom'];
$_SESSION['prenomUp']=$resultat['prenom'];
?>
<!-- tableau de présentation update-->
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <fieldset class="emp">
                    <legend>Modifier Employé</legend>
                    <form name="update" method="POST" action="../controller/traitement_update.php">
                        <div class="col-md-3"></div>
                        <div class="col-md-6">
                            <label for="nom">Nom : </label>
                            <input class="input" type="text" value="<?php  echo $resultat['nom'];?>" name="nom" id="nom" disabled="disabled" required><br><br>

                            <label for="prenom">Prénom : </label>
                            <input class="input" type="text" value="<?php  echo $resultat['prenom'];?>"  name="prenom" id="prenom" disabled="disabled" required><br><br>

                            <label for="prenom">Adresse : </label>
                            <textarea class="input" type="text" value=""  name="adresse" id="adresse" required><?php  echo $resultat['adresse'];?></textarea><br><br>

                            <label for="fonction">Fonction : </label>
                            <select name="fonction" id="fonction">
                                <option value="<?php echo $resultat['fonction']?>"><?php echo ucwords(strtolower($resultat['fonction']))?></option>
                                    <?php
                                        while($reponse4=$req4->fetch()){
                                        echo '<option value="'.$reponse4['fonction'].'">'.ucwords(strtolower($reponse4['fonction'])).'</option>';
                                        }
                                    ?>
                                <option value="Autre">Autre</option>
                            </select>
                            <br><br>
                            <!--style="display: none"    /   style="display: none ; width: 50%; height: 10%; margin-left: 25%; padding: 3%; padding: left 10%; border-radius :25%;"-->
                            <span id="fonctionA" style="display: none;">
                            <label for="fonctionA">Entrez une nouvelle fonction : </label>
                            <input type="text" id="Autre" name="fonctionA" class="input" placeholder="Nouvelle Fonction"></textarea>
                            <br><br>
                            </span>

                            <script type="text/javascript">
                                var select = document.getElementById('fonction');
                                select.onchange = function(){
                                    var span = document.getElementById('fonctionA');
                                    if(this.value == 'Autre'){
                                        span.style.display='block';
                                    }
                                    else{
                                        span.style.display ='none'; 
                                    } 
                                }
                            </script>

                            <label for="embauche">Date Embauche : </label>
                            <input class="input" type="date" value="<?php  echo $resultat['embauche'];?>" name="embauche" id="embauche" disabled="disabled"><br><br>

                            <label for="tauxH">Taux Horaire : </label>
                            <input class="input" type="text" value="<?php  echo $resultat['tauxH'];?>"  name="tauxH" id="tauxH"><br><br>

                            <label for="comm">Commission : </label>
                            <input class="input" type="text" value="<?php  echo $resultat['comm'];?>"  name="comm" id="comm"><br><br>

                            <label for="prime">Prime : </label>
                            <input class="input" type="text" value="<?php  echo $resultat['prime'];?>"  name="prime" id="prime"><br><br>

                            <label for="dtn">Date de naissance : </label>
                            <input class="input" type="date" value="<?php  echo $resultat['naissance'];?>" name="dtn" id="dtn" disabled="disabled"><br><br>

                            <label for="mail">Adresse e-mail : </label>
                            <input class="input" type="mail" value="<?php  echo $resultat['mail'];?>"  name="mail" id="mail" required><br><br>

                            <label for="noServ">Service : </label>
                            <select name="service" id="service">
                                <option value="<?php echo $resultat['noServ']?>"><?php echo ucwords(strtolower($resultat['service']))?></option>
                                    <?php 
                                        while($reponse3=$req3->fetch()){
                                            echo '<option value="'.$reponse3['noServ'].'">'.ucwords(strtolower($reponse3['service'])).'</option>';
                                        }
                                    ?>
                            </select>
                            <br><br>

                            <label for="tel">Téléphone : </label>
                            <input class="input" type="tel" value="<?php  echo $resultat['tel'];?>"  name="tel" id="tel"><br><br><br>

                            <input class="submit envoyer" type="submit" value="update"><br>
                            <a href="redirection.php?section=employe"><input class="button envoyer" type="button" value="Retour" ></a>
                        </div>
                        <div class="col-md-3"></div>
                    </form>
                </fieldset>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div><br /><br />

<?php include('footer.php') ?>
</body>
</html>