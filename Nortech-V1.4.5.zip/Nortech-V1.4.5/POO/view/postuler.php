<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
        </script>";
}
$nav_en_cours = 'espace_perso';
// ce document html contient un formulaire avec un champ nommé `fichier` permettant de pousser (uploader) un fichier vers un serveur
include('header.php');
echo '<br /><br />';
//session_start();
$nom=$_SESSION['nom'];
$sql="SELECT e.noEmp FROM historique h,employe e, utilisateur u where h.identifiant=u.identifiant AND e.noEmp=u.noEmp AND e.nom=:nom group by e.nom";
$req=$connexion->prepare($sql);
$reponse=$req->execute(array('nom'=>$nom));
//$resultat=$reponse->fetch();
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="css/postuler.css">
</head>

<body>

    <?php // il faut utiliser l'attribut `enctype="multipart/form-data"` pour que le fichier puisse être envoyé ?>
        <div class="container-fluid">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <fieldset class="postuler">
                <legend><u>Postuler à une offre</legend></u><br />
    <form action="" method="post" enctype="multipart/form-data">
        <div>
            <div>
                <label for="nom">Nom: </label>
            </div>
            <div>
                <input type="text" name="nom" class='input' required>
            </div>
        </div>
        <div>
            <div>
                <label for="prenom"> Prénom: </label>
            </div>
            <div>
                <input type="text" name="prenom" class='input' required>
            </div>
        </div>

        <label for="fichier">Votre CV </label><br />
        <input class="choisir" name="CV" type="file" required/><br />

        <label for="fichier">Votre lettre de motivation</label><br />
        <input class="choisir" name="LM" type="file" required/><br />

<input class="envoyer" type="submit" value="Envoyer" />
        <a href="redirection.php?section=offreemploi"><input class="envoyer" type="button" value="Retour" /></a>
    </form><br>
                </fieldset>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>

<?php
    
    while($resultat=$req->fetch()){
   



    // la variable `$_FILES` est un tableau
    // avant que l'utilisateur ne valide le formulaire la variable `$_FILES` ne contient aucune donnée
    // quand l'utilisateur valide le formulaire, on retrouve les information concernant le fichier uploadé dans la variable `$_FILES`

    if(isset($_POST['nom'])){
        
        $nom=$_POST['nom']; 
        $prenom=$_POST['prenom']; 
        $anderscore='_';
        $noEmp=$resultat['noEmp'];
        
            
            //recupère le CV et l'envoie dans le dossier files 
            $fileCV=$_FILES['CV']['name'];//recupère 
            $fileextensionCV=strrchr($fileCV,".");
                
            //recupère le CV et l'envoie dans le dossier files 
            $fileLM=$_FILES['LM']['name'];//recupère 
            $fileextension=strrchr($fileLM,".");
                
            if($fileextension == '.pdf' || $fileextension=='.odt' || $fileextension=='.docx'){

                //recupère le CV et l'envoie dans le dossier files 
            $fileCV=$_FILES['CV']['name'];//recupère 
            $fileextensionCV=strrchr($fileCV,".");
                
            //recupère le CV et l'envoie dans le dossier files 
            $fileLM=$_FILES['LM']['name'];//recupère 
            $fileextension=strrchr($fileLM,".");
                    
                //recupère le format du fichier 
                $filetmpCV=$_FILES['CV']['tmp_name'];
                //le stock dans un dossier temporaire 
                $filedestCV='../../CV/'.$fileCV;
                //donne le repertoire de stockage 
                move_uploaded_file($filetmpCV,$filedestCV);
                //le deplace dans le dossier files  
                rename("$filedestCV", "../../CV/ $noEmp$anderscore$nom$anderscore$prenom$fileextensionCV");//renome le CV

                //recupère le format du fichier 
                $filetmp=$_FILES['LM']['tmp_name'];
                //le stock dans un dossier temporaire 
                $filedest='../../LM/'.$fileLM;
                //donne le repertoire de stockage 
                move_uploaded_file($filetmp,$filedest);
                //le deplace dans le dossier files  
                rename("$filedest", "../../LM/ $noEmp$anderscore$nom$anderscore$prenom$fileextension");//renome le CV

             
                echo "<script type='text/javascript'>document.location.replace('offreemploi.php');alert('Votre canditature a été enregistrée avec succés.');</script>";
              
              

            }else{
                echo "<script type='text/javascript'>document.location.replace('postuler.php?section=Offre_d_emploi');alert('Veuillez mettre un fichier en format PDF ou WORD.');</script>";
            }
    }
} 
echo '<br /><br />';     

include('footer.php');
?>

</body>

</html>