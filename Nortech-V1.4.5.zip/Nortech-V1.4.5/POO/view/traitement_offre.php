<?php
session_start();
require('../common/modele/dbSingleton.php');
$dbi = DbSingleton::getInstance();
$connexion=$dbi->getConnection();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('../view/index.php');
                </script>";
}
else{
        $nav_en_cours ='offreemploi';
    $action=$_GET['action'];

    if($action=='ajouter'){
        
    $titre=$_POST['titre'];
    $serv=$_POST['service'];
    $dat=$_POST['date'];
    $ville=$_POST['ville'];
    $descrip=$_POST['descrip'];

    $sql='SELECT * FROM nortech.annonce where noannonce=:id';
    $req=$connexion->prepare($sql);
    $reponse=$req->execute(array('id'=>$titre));
    $resultat=$req->fetch();

    $sql="INSERT INTO nortech.annonce(`titre`, `service`, `dateAnnonce`, `ville`, `description`) VALUES (:id,:serv,:date,:ville,:descrip)";
    $req=$connexion->prepare($sql);
    $reponse=$req->execute(array('id'=>$titre,'serv'=>$serv,'date'=>$dat,'ville'=>$ville,  'descrip'=>$descrip));

    if(!$reponse){
        echo "<script type='text/javascript'>document.location.replace('../view/ajouter_annonce.php?section=offre');
                        alert('l\'enregistrement de l\'annonce a échoué ! Veuillez vérifier vos saisies.');
                        </script>";
            }else{
            echo "<script type='text/javascript'>document.location.replace('../view/redirection.php?section=offreemploi');
                        alert('Annonce enregistrée avec succès !');
                        </script>";

    }
    }
    elseif($action=='supprimer'){
        $noannonce=$_POST['noannonce'];
    $sql='SELECT * from nortech.annonce where noannonce= :id';
    $req=$connexion->prepare($sql);
    $reponse=$req->execute(array('id'=>$noannonce));
    $resultat=$req->fetch();
    if(!$resultat){
        echo "<script type='text/javascript'>document.location.replace('../view/redirection.php?section=".$section."');
                        alert('Ce numéro ne correspond à aucune annonce de la BDD!');
                        </script>";
            }else{
                $sql='DELETE FROM nortech.annonce WHERE noannonce=:id';

                $req=$connexion->prepare($sql);
                $reponse=$req->execute(array('id'=>$noannonce));
                if(!$reponse){
                    echo "<script type='text/javascript'>document.location.replace('../view/supprimer_annonce.php?section=offre');
                                alert('La suppression de cette annonce a échoué!');
                                </script>";
                    }else{
                
                        echo "<script type='text/javascript'>document.location.replace('../view/redirection.php?section=offreemploi');
                                alert('Annonce supprimée avec succès!');
                                </script>";
    }
            }
    }elseif($action=='update'){
        $id=$_GET['id'];	
        $noannonce=$_POST['noannonce'];
        $titre=$_POST['titre'];
        $serv=$_POST['service'];
        $ville=$_POST['ville'];
        $descrip=$_POST['descrip'];
        
        $sql='SELECT * FROM nortech.annonce where noAnnonce=:id';
        $req=$connexion->prepare($sql);
        $reponse=$req->execute(array('id'=>$id));
        $resultat=$req->fetch();
        if(!$resultat){
            echo "<script type='text/javascript'>document.location.replace('../view/redirection.php?section=offreemploi');
            alert('Impossible de mettre à jour, l'offre est inconnue !');
                        </script>"; 
                    }else{

                        $sql='SELECT * FROM nortech.annonce where noAnnonce=:id';
                        $req=$connexion->prepare($sql);
                        $reponse=$req->execute(array('id'=>$noannonce));
                        $resultat=$req->fetch();
                        if(!$resultat){
                            echo "<script type='text/javascript'>document.location.replace('../view/update.php?section=offreemploi&id=".$id."');
                                    alert('Vous ne pouvez pas prendre ce numéro d'offre !');
                                    </script>";
                        }else{
                
                        $sql="UPDATE nortech.annonce SET titre=:titre,service=:serv,ville=:ville,description=:descrip WHERE noAnnonce=:id";
                
                        
                        $req=$connexion->prepare($sql);
                        $reponse=$req->execute(array('titre'=>$titre,'serv'=>$serv,'ville'=>$ville,  'descrip'=>$descrip,'id'=>$noannonce));
                    
                            if(!$reponse){
                                echo "<script type='text/javascript'>//document.location.replace('../view/update.php?section=offre&noffre=24');
                                        alert('la mise a jour de l\'annonce a échoué ! Veuillez vérifier vos saisies.');
                                        </script>";
                            }else{

                                echo "<script type='text/javascript'>document.location.replace('../view/redirection.php?section=offreemploi');
                                        alert('Annonce mise a jour avec succès !');
                                        </script>";
                                        /*var_dump($id);
                                        var_dump($noannonce);
                                        var_dump($titre);
                                        var_dump($serv);
                                        var_dump($dat);
                                        var_dump($ville);
                                        var_dump($descrip);*/
                            }
                            
                        }
                    }
    }
    else{
        echo " <script type='text/javascript'> 
        //document.location.replace('../view/redirection.php');
        alert('Cette action est interdite !!! ');
    </script>";
    }







    echo "----------------------------------------------<br>";
    echo '  <a href="redirection.php">Accueil</a>';
}
?>