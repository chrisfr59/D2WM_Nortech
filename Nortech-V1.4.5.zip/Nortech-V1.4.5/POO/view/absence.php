<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Absences</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="SACI_MH">
    <link rel="stylesheet" type="text/css" media="screen" href="css/absence.css" />
    <!--Fonction qui permet de modifier la visibilité-->
    <script>
    function afficher(etat){
        document.getElementById("champ").style.visibility=etat;
    }
    </script>
</head>
<body>
    
<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
        </script>";
}
$nav_en_cours = 'espace_perso';
include ('header.php');
?>

<div class="container-fluid">
    <!--Formulaire d'absences et de congés-->
    <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-4">
        <form name="absence" method="post" action="../controller/traitement_absence.php" enctype="multipart/form-data">
                    <fieldset class="absform">
                        <legend><u>Déclarer une absence</legend></u><br />
                        <div class="row">
                            <div class="col-md-12 declaration">
                            <p><u>Type d'absence à déclarer :</u><br /><br />
                                <label class="choix" for="absence">Absence</label>
                                <!--Si le radio = absence : afficher la div "champ" qui correspond au justifcatif-->
                                <input type="radio" name="types" value="Absences" id="absence" onclick="afficher('visible');" checked>
                                <label class="choix" for="conges">Congés</label>
                                <!--Si le radio = conges : masquer la div "champ" qui correspond au justifcatif-->
                                <input type="radio" name="types" value="Congés" id="conges" onclick="afficher('hidden');">
                            </p>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                        <label class="label date" for="dateAbsD"><u>Dates :</u></label>
                        <span class="du">Du : </span><input class="input" type="date" name="dateAbsD" id="dateAbsD" required/><br /><br />
                        <label class="label" for="dateAbsF"></label>
                        <span class="au">Au : </span><input class="input" type="date" name="dateAbsF" id="dateAbsF" required/><br /><br />
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                        <label class="label motif" for="motif"><u>Motif :</u></label>
                        <textarea class="input textarea" type="text" name="motif" id="motif"></textarea><br /><br />
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div id="champ">
                                <label class="label justificatif" for="justificatif"><u>Justificatif :</u></label><br />
                                <input class="input choisir" type="file" name="justificatif" id="justificatif"/><br /><br />
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                        <input class="envoyer" name="envoyer" class="btn-submit" type="submit" value="Envoyer" />
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
        <div class="col-md-4"></div>
    </div><br /><br /><br /><br />

    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <fieldset class="absform">
                <legend><u>Historique des absences</u></legend><br><br>
                <div class="row">
                    <div class="col-md-4">
                    <p class="search">Rechercher un employé :</p><br />
                    </div>
                    <div class="col-md-2"></div>
                    <div class="col-md-2">
                        <p class="absence">Dates des absences :</p><br />
                    </div>
                    <div class="col-md-4"></div>
                </div>

<!--Historique de congés-->
                <div class="row">
                    <div class="col-md-4">
                        <form class="search_bar" role="search" method="get" action="">
                            <input class="search-field" type="number" placeholder="Ex : 1100" name="recherche" id="recherche" /><br /><br />
                            <input class="search-submit envoyer" value="Rechercher" type="submit" name="submit"/><br />
                            <input type="submit" class="search-submit-back envoyer" value="Revenir à mes congés" name="retour" href="absence.php"><br />
                            <p class="dateAbsence">Dates des absences :</p><br />
                        </form>
                    </div>
                    <div class="col-md-7">
                        <fieldset class="absform">
                            <?php
                            //Fonction de recherche d'un employé/affichage des congés de l'employé recherché dans le fieldset
                            function rechercher($noEmp){
                                global $connexion;
                                $req = $connexion->prepare('SELECT e.noEmp, e.nom, e.prenom, a.types, DATE_FORMAT(a.dateAbsD,"%d-%m-%Y"), DATE_FORMAT(a.dateAbsF,"%d-%m-%Y"), a.motif FROM nortech.employe e, nortech.absence a where e.noEmp=a.noEmp ORDER BY a.dateAbsD DESC');
                                $reponse=$req->execute(array());
                                    if (isset($reponse)){
                                        while($resultat=$req->fetch()){
                                            if ($resultat['noEmp'] == $noEmp){
                                                echo '<tr>';
                                                echo '<td>'.$resultat['noEmp'].'</td> - 
                                                <td>'.$resultat['nom'].'</td>
                                                <td>'.$resultat['prenom'].'</td> - 
                                                <td>'.$resultat['types'].'</td> : du
                                                <td>'.$resultat['DATE_FORMAT(a.dateAbsD,"%d-%m-%Y")'].'</td> au 
                                                <td>'.$resultat['DATE_FORMAT(a.dateAbsF,"%d-%m-%Y")'].'</td> - 
                                                <td>'.$resultat['motif'].'</td>';
                                                echo '<tr><br />';
                                            }
                                        }
                                    } 
                                }
                                    //Condition de recherche
                                    if(isset($_GET["submit"])==true){            
                                        if(isset($_GET["submit"])){
                                            $recherche=$_GET["recherche"] ;
                                            rechercher($recherche);
                                        }
                                        echo '<br />';
                                }else{  
                                    //Requête pour afficher les congés de la personne loggée dans le fieldset
                                    $sql='SELECT e.noEmp, e.nom, e.prenom, a.types, DATE_FORMAT(a.dateAbsD,"%d-%m-%Y"), DATE_FORMAT(a.dateAbsF,"%d-%m-%Y"), a.motif FROM nortech.absence a, nortech.employe e, nortech.utilisateur u WHERE a.noEmp=e.noEmp AND e.noEmp=u.noEmp AND u.identifiant like "'.$_SESSION['pseudo'].'" ORDER BY a.dateAbsD DESC';
                                    
                                    //Affichage des congés de la personne loggée dans le fieldset
                                    $req1=$connexion->prepare($sql);
                                    $reponse1=$req1->execute(array());
                                    while($resultat1=$req1->fetch()){
                                        echo '<tr>';
                                        echo '
                                        <td>'.$resultat1['noEmp'].'</td> - 
                                        <td>'.$resultat1['nom'].'</td>
                                        <td>'.$resultat1['prenom'].'</td> - 
                                        <td>'.$resultat1['types'].'</td> : du
                                        <td>'.$resultat1['DATE_FORMAT(a.dateAbsD,"%d-%m-%Y")'].'</td> au 
                                        <td>'.$resultat1['DATE_FORMAT(a.dateAbsF,"%d-%m-%Y")'].'</td> -  
                                        <td>'.$resultat1['motif'].'</td><br />';
                                        echo '</tr>';
                                    };

                                }
                            ?>
                        </fieldset><br /><br />
                    </div>
                    <div class="col-md-1"></div>
                </div>
                <!--Affichage jours de congés pris et jours de congés restants-->
                <div class="row">
                    <div class="col-md-4"></div>
                    <div class="col-md-7">
                    <p>Jours de congés pris :
                    <?php   
                    //Modifier l'affichage des jours de congés pris en fonction de la personne recherchée
                    if(isset($_GET["submit"])==true){            
                        if(isset($_GET["submit"])){
                            $recherche=$_GET["recherche"];
                            
                        //Calculer le nombre de jours pris par rapport au formulaire de la personne recherchée
                        $dateAbsD='2018-05-10';
                        $dateAbsF='2018-05-20';
                        $tabDateD=explode("-", $dateAbsD);
                        $tabDateF=explode("-", $dateAbsF);
                        $nbrPris=(mktime(12,0,0, $tabDateF[1], $tabDateF[2], $tabDateF[0]) - mktime(12,0,0, $tabDateD[1], $tabDateD[2], $tabDateD[0]))/60/60/24;
                    
                        //récupérer la colonne nbJPris de la personne recherchée dans la bdd et les additionner
                        $sql="SELECT SUM(nbJPris) as nombre FROM nortech.absence WHERE noEmp=$recherche";
                        $req2=$connexion->prepare($sql);
                        $reponse2=$req2->execute(array());
                        $test=0;
                        while($resultat2=$req2->fetch()){
                            echo '<tr>';
                            echo '
                            <td>'.$resultat2['nombre'].'</td><br />';
                            echo '</tr>';
                            $test+=$resultat2['nombre'];
                        }
                    };
                    ?>

                    <?php   
                        
                    //Calculer le nombre de jours pris par rapport au formulaire de la personne loggée
                    }else{
                            $dateAbsD='2018-05-10';
                            $dateAbsF='2018-05-10';
                        $tabDateD=explode("-", $dateAbsD);
                        $tabDateF=explode("-", $dateAbsF);
                        $nbrPris=(mktime(12,0,0, $tabDateF[1], $tabDateF[2], $tabDateF[0]) - mktime(12,0,0, $tabDateD[1], $tabDateD[2], $tabDateD[0]))/60/60/24;

                        //récupérer la colonne nbJPris de la personne loggée dans la bdd et les additionner
                        $sql='SELECT SUM(a.nbJPris) as nombre FROM nortech.employe e, nortech.absence a, nortech.utilisateur u WHERE a.noEmp=e.noEmp AND e.noEmp=u.noEmp AND u.identifiant like "'.$_SESSION['pseudo'].'"';
                        $req2=$connexion->prepare($sql);
                        $reponse2=$req2->execute(array());
                        $test=0;
                        while($resultat2=$req2->fetch()){
                            echo '<tr>';
                            echo '
                            <td>'.$resultat2['nombre'].'</td><br />';
                            echo '</tr>';
                            $test+=$resultat2['nombre'];
                    }
                };
                    ?>  
                </p>
                <p>Jours de congés restants :
                    <?php
                    //Afficher le nombre de jours restants
                        $nbrRestant=30-$test;
                        echo $nbrRestant;
                    ?>
                </p>
                    </div>
                    <div class="col-md-1"></div>
                </div>
            </fieldset>
        </div>
        <div class="col-md-2"></div>
    </div>
</div><br /><br />


<?php
include('footer.php');
?>
  
</body>
</html>