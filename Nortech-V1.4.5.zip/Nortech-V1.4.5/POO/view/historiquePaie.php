<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/historiquePaie.css">

<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('../view/index.php');
                </script>";
}
$nav_en_cours = 'espace_perso';
include('header.php');

echo '<h1>Historique des fiches de paie 2018</h1><br>';
$nb_fichier = 0;
echo '<ul class="annee">';
if($dossier = opendir('../../paye')){
    
    while(false !== ($fichier = readdir($dossier)))
    {
        if($fichier != '.' && $fichier != '..' && $fichier != 'index.php'){
            if($_GET['id'] ==substr($fichier,0,4) ){
            $nb_fichier++; // On incrémente le compteur de 1
            
            
            $mois=substr($fichier,5,-10);
           
           switch ($mois) {
            case '01':
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Janvier"></a><br><br>';
                break;
            case "02":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Février"></a><br><br>';
                break;
            case "03":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Mars"></a><br><br>';
                break;
            case "04":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Avril"></a><br><br>';
                break;
            case "05":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Mai"></a><br><br>';
                break;
            case "06":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Juin"></a><br><br>';
                break;
            case "07":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Juillet"></a><br><br>';
                break;
            case "08":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Août"></a><br><br>';
                    break;
            case "09":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Septembre"></a><br><br>';
                break;
            case "10":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Octobre"></a><br><br>';
                break;
            case "11":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Novembre"></a><br><br>';
                break;
            case "12":
            echo '<a href="../../paye/' . $fichier . '"><input class="mois" type="button" value="Décembre"></a><br><br>';
                break;
        }
        
        
        
        }
            
        } // On ferme le if (qui permet de ne pas afficher index.php, etc.)
    } // On termine la boucle

    echo '</ul><br />';
    echo 'Nombre de fiche de paie disponible : <strong>' . $nb_fichier .'</strong> ';
    closedir($dossier);
    
}else{
    echo 'Le dossier n\' a pas pu être ouvert';
}

include('footer.php');



?>

