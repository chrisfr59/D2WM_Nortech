<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
$nav_en_cours = 'espace_perso';

    //appeler la connexion à la BDD
    include ('header.php');
    echo '<br /><br />';

$nom=$_SESSION['nom'];
$sql="SELECT e.noEmp FROM employe e where e.nom=:nom group by e.nom";
$req=$connexion->prepare($sql);
$reponse=$req->execute(array('nom'=>$nom));
//$resultat=$reponse->fetch();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Dépenses</title>
    <link rel="stylesheet" type="text/css" href="css/depense.css">
    <script language="JavaScript">
    function afficher(){
        var a = document.getElementById("autre");
        var m = document.getElementById("mots");
    
        if (document.frais.motif.value == "Autre"){
            if (a.style.display == "none")
            a.style.display = "block";
           if (m.style.display == "none")
            m.style.display = "block";
        }
        else{
            a.style.display = "none"; 
            m.style.display = "none"; 
        }
    }
    
    </script>
</head>
<body>
    <div class="container-fluid">
        <div class="row ">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <fieldset class='depense'>
                    <legend><u>Note de frais</u></legend>
                    <form name="frais" method="POST" action="../controller/traitement_frais.php?section=frais&action=ajouter">

                        <label for="noEmp">Numéro d'employé :</label>
                        <input type="text" name="noEmp" class="form-control" placeholder="Numéro employé" value="<?php while($resultat=$req->fetch()){echo $resultat['noEmp'];}  ?>" readonly/><br /><br />
                        
                        <label for="montant">Montant de la dépense :</label>
                        <input type="number" step='0.01' min="0" max="100000" name="montant" class="form-control" placeholder="Montant en €" value="" required/><br /><br />

                        <label for="date">Date de la dépense :</label><br />
                        <input type="date" name="date" min="2018-09-01" class="form-date" placeholder="Date" value="" required/><br /><br />

                        <label for="motif">Motif de la dépense :</label><br />
                        <select required type="text" name="motif" class="form-deroul" onChange="afficher()" >
                                <option value="" selected disabled>-- Choisissez un motif --</option> 
                                <option value="Carburant">Carburant</option>
                                <option value="Fournitures">Fournitures</option>
                                <option value="Hebergement">Hébergement</option>
                                <option value="Restauration">Restauration</option>
                                <option value="Autre">Autre</option>
                        </select><br />

                        <span id=autre style="display: none"></span>
                        <br>
                        <textarea value="" id="mots" name="autreMotif" class="form-controle" placeholder="Pour tout autre motif, merci d'expliquer en quelques mots ..." 
                        style="display: none ; width: 50%; height: 10%; margin-left: 25%; padding: 3%; padding: left 10%; border-radius :25%;"></textarea><br />

                        <input class="envoyer" type="submit" name="btnSubmit" class="btnContact" value="Envoyer" />
                        <input class="envoyer" type="reset" name="effacer" class="btnContact" value="Effacer" />
                        <a href="espace_perso.php"><input class="envoyer" type="button" value="Retour à l'espace personnel" ></a>


                    </form>
                </fieldset>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
</body>
</html>