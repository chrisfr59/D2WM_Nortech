<?php
    if(empty($_SESSION)){
        echo "<script type='text/javascript'>document.location.replace('index.php');
                    </script>";
    }
    require('../common/modele/dbSingleton.php');
    $dbi = DbSingleton::getInstance();
    $connexion=$dbi->getConnection();
?>
<!DOCTYPE html> 
<html lang="fr">
	<head>
		<title>NorTech - Bienvenue</title>
		<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!--Fontawesom-->
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <!--Bootstrap Carousel-->
        <!--Main Stylesheet-->
        <link href="css/style.css" rel="stylesheet">
        <!--Responsive Framework-->
        <link href="css/responsive.css" rel="stylesheet">
        

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->


		
	</head>
	<body>
		<section id="header">
            <div class="header-area">
                <div class="top_header">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 zero_mp">
                                <div class="address">
                                    <i class="fa fa-home floatleft"></i>
                                    <p>41-43 Rue du Faubourg Saint-Honoré, 75008 Paris, France</p>
                                </div>
                            </div>
                            <!--End of col-md-4-->
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4 zero_mp">
                                <div class="phone">
                                    <i class="fa fa-phone floatleft"></i>
                                    <p>+33 1 02 03 04 05</p>
                                </div>
                                
                            </div>
                            <!--End of col-md-4-->
                            <div class="col-md-4">
                                <div class="social_icon text-right">
                                    <a href=""><i class="fa fa-facebook"></i></a>
                                    <a href=""><i class="fa fa-twitter"></i></a>
                                    <a href=""><i class="fa fa-google-plus"></i></a>
                                    <a href=""><i class="fa fa-youtube"></i></a>
                                </div>
                            </div>
                            <!--End of col-md-4-->
                        </div>
                        <!--End of row-->
                    </div>
                    <!--End of container-->
                </div>
                <!--End of top header-->
                <div class="header_menu text-center" data-spy="affix" data-offset-top="50" id="nav">
                    <div class="container">

			    
			
                        <nav class="navbar navbar-default zero_mp ">
                            <!-- Brand and toggle get grouped for better mobile display -->
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <a class="navbar-brand custom_navbar-brand"><img src="img/nortechLogo.png"  id="logo" alt=""></a>
                            </div>
                            <!--End of navbar-header-->
                            <div class="row" id="connect">

                                <div class="col-xs-12 col-md-6" id="login">
			                         <h3>Bonjour <?php echo $_SESSION['nom'].' '.$_SESSION['prenom'];?></h3>
                                </div>
                                <div class="col-xs-12 col-md-6"id="login">   
			                         <p>Dernière connexion le : <?php echo $_SESSION['dateConnection'];?></p>
                                </div>
   
			
			             </div>

                            <!-- Collect the nav links, forms, and other content for toggling -->
                            <div class="collapse navbar-collapse zero_mp" id="bs-example-navbar-collapse-1">
                                <ul class="nav navbar-nav navbar-right main_menu">
                                    <li <?php if ($nav_en_cours == 'espace_perso') {echo ' id="en-cours"';} ?>><a href="redirection.php?section=espace_perso" id="recherche">Espace Personnel</a></li>
                                    <li <?php if ($nav_en_cours == 'service') {echo ' id="en-cours"';} ?>><a href="redirection.php?section=service" id="recherche">Service</a></li>
                                    <li <?php if ($nav_en_cours == 'employe') {echo ' id="en-cours"';} ?>><a href="redirection.php?section=employe" id="recherche">Employé</a></li>
                                    <li <?php if ($nav_en_cours == 'user') {echo ' id="en-cours"';} ?>><a href="redirection.php?section=user" id="recherche">Utilisateur</a></li>
                                    <li <?php if ($nav_en_cours == 'offre_emploi') {echo ' id="en-cours"';} ?>><a href="redirection.php?section=offreemploi" id="recherche">Offres d'emploi</a></li>
									<li><button class=" btn btn-success btn-lg btn-block"><a href="../controller/deconnexion.php">Déconnexion</a></button></li>
                                </ul>
                            </div>
                            <!-- /.navbar-collapse -->
                        </nav>
                        <!--End of nav-->
                    </div>
                    <!--End of container-->
                </div>
                <!--End of header menu-->
            </div>
            <!--end of header area-->
        </section>
        <!--End of Hedaer Section-->
        <script src="js/jquery-1.12.3.min.js"></script>

        <!--Counter UP Waypoint-->
        <script src="js/waypoints.min.js"></script>
        <!--Counter UP-->
        <script src="js/jquery.counterup.min.js"></script>

        <script>
            //for counter up
            $('.counter').counterUp({
                delay: 10,
                time: 1000
            });
        </script>

        <!--Isotope-->
        <script src="js/isotope/min/scripts-min.js"></script>
        <script src="js/isotope/cells-by-row.js"></script>
        <script src="js/isotope/isotope.pkgd.min.js"></script>
        <script src="js/isotope/packery-mode.pkgd.min.js"></script>
        <script src="js/isotope/scripts.js"></script>




        <!--JQuery Click to Scroll down with Menu-->
        <script src="js/jquery.localScroll.min.js"></script>
        <script src="js/jquery.scrollTo.min.js"></script>
        <!--WOW With Animation-->
        <script src="js/wow.min.js"></script>
        <!--WOW Activated-->
        <script>
            new WOW().init();
        </script>


        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>
        <!-- Custom JavaScript-->
        <script src="js/main.js"></script>