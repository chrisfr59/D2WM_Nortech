<?php
$date_FR=date("F");


switch ($date_FR) {
    case 'January':
        return $mois_FR="Janvier";
        break;
    case "February":
        return $mois_FR="Fevrier";
        break;
    case "March":
        return $mois_FR="Mars";
        break;
    case "April":
        return $mois_FR="Avril";
        break;
    case "May":
        return $mois_FR="Mai";
        break;
    case "June":
        return $mois_FR="Juin";
        break;
    case "July":
        return $mois_FR="Juillet";
        break;
    case "August":
        return $mois_FR="Aout";
            break;
    case "September":
        return $mois_FR="Septembre";
        break;
    case "October":
        return $mois_FR="Octobre";
        break;
    case "November":
        return $mois_FR="Novembre";
        break;
    case "December":
        return $mois_FR="Decembre";
        break;
    }





?>