<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="css/formpaie.css">
    <title>Site Nortech</title>
</head>

<body>


<?php
$nav_en_cours = 'espace_perso';
//appeler la connexion à la BDD
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
include ('header.php');


$noEmp=$_GET['id'];
$date= date("m");
$sql="SELECT e.* ,a.types FROM employe e  left join absence a on a.noEmp=e.noEmp where e.noEmp=:noEmp  ";
$req=$connexion->prepare($sql); 
$reponse=$req->execute(array('noEmp'=>$noEmp,)); 


?>
<?php 
while($resultat=$req->fetch()){ 
    $type= $resultat['types'];
    
   
   
?>


    <br /><form name="paie" method="POST" action="traitement_paie.php">

        <h1><u>Création d'une fiche de paie</u></h1><br>
        <div class="form">
            <div class="titre">
                Mois :
                <select name="mois" id="mois" required>

                    <option value="01Janvier">Janvier <?php echo date("Y");?></option>
                    <option value="02Février">Février <?php echo date("Y");?></option>
                    <option value="03Mars">Mars <?php echo date("Y");?></option>
                    <option value="04Avril">Avril <?php echo date("Y");?></option>
                    <option value="05Mai">Mai <?php echo date("Y");?></option>
                    <option value="06Juin">Juin <?php echo date("Y");?></option>
                    <option value="07Juillet">Juillet <?php echo date("Y");?></option>
                    <option value="08Août">Août <?php echo date("Y");?></option>
                    <option value="09Septembre">Septembre <?php echo date("Y");?></option>
                    <option value="10Octobre">Octobre <?php echo date("Y");?></option>
                    <option value="11Novembre">Novembre <?php echo date("Y");?></option>
                    <option value="12Décembre">Décembre <?php echo date("Y");?></option>
                </select>
                
            </div><br>
            <div class="row">
            <div class="fonction">
                    <div class="employe">
                        Fonction :
                        <input type="text" name="fonction" class="form-control" value="<?php echo $resultat['fonction'];?>"
                            readonly />
                    </div>
                    <div class="employe">
                        Taux horaire :
                        <input type="number" name="taux" class="form-control" value="<?php echo $resultat['tauxH'];?>"
                            readonly />
                    </div>
                    </div>
                <div class="employe">
               
                <div class="employe">
                        N°Employé :
                        <input type="text" name="noemp" class="form-control" value="<?php echo $resultat['noEmp'];?>"
                            readonly />
                    </div>

                    <div class="employe">
                        Nom :
                        <input type="text" name="nom" class="form-control" value="<?php echo $resultat['nom'];?>"
                            readonly />
                    </div>

                    <div class="employe">
                        Prénom :
                        <input type="text" name="prenom" class="form-control" value="<?php echo $resultat['prenom'];?>"
                            readonly />
                    </div>
                    
                    <div class="adresse">
                        Adresse :
                        <input type="text" name="adresse" class="form-control" value="<?php echo $resultat['adresse'];?>"
                            readonly />
                    </div>
                    </div>

               
                
            
                    
                <div class="salaire">
                    <div class="salaire">
                        Nombre d'heures :
                        <input type="number" name="heures" class="form-control" placeholder="Nombre d'heures" required />
                    </div>

                    

                    <div class="salaire">
                        Prime :
                        <input type="number"  min='0' max= '50 000' name="prime" class="form-control" placeholder="Prime" required />                     
                    </div> 

                    <div class="salaire">                         
                        Commission :                         
                        <input type="number" min='0' max= '50 000' name="commission" class="form-control" placeholder="Commission" required />                     
                    </div>

                    <div class="salaire">
                        Congés :
                        <input type="number" name="conges" class="form-control" value="<?php 
            
                    $noEmp=$_GET['id'];
                    $sql="
                            SELECT types, sum(nbJPris) FROM `absence` WHERE `types`='Congés' and noEmp=:noEmp"; $req=$connexion->prepare($sql);
                        $reponse=$req->execute(array('noEmp'=>$noEmp,));

                        while($resultat=$req->fetch()){
                        echo $resultat['sum(nbJPris)']+0;

                        }
                        ?>" readonly />
                    </div>
                    <div class="salaire">
                        Absences :
                        <input type="number" name="absence" class="form-control" value="<?php $noEmp=$_GET['id'];$sql="
                            SELECT types,sum(nbrJA) FROM absence WHERE types='Absences' and noEmp=:noEmp"; $req=$connexion->prepare($sql);
                        $reponse=$req->execute(array('noEmp'=>$noEmp,));

                        while($resultat=$req->fetch()){
                        echo $resultat['sum(nbrJA)']+0;
                        }
                        ?>" readonly />
                    </div>

                </div>

            </div>

            <div class="row">
                <div class="end">
                    
                    <div class="date">
                        Date de paiement :
                        <input type="date" name="date" class="form-control" placeholder="Date de paiement" required />
                    </div><br>

                    <div class="bouton">
                        <input type="submit" name="btnSubmit" class="btnContact envoyer" value="Envoyer" />
                        <input type="reset" name="effacer" class="bnt envoyer" value="Effacer" />
                        <a href="espace_perso.php" class="retour"><input type="button" class ="envoyer" value="Retour à l'espace personnel"></a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</body>

</html>

<?php } ?>