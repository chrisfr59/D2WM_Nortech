<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
else{
    $nav_en_cours = 'espace_perso';
    //appeler la connexion à la BDD
    include('header.php');
    echo '<br /><br/>';
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" href="css/depense.css">
</head>
<body>
    <h3 class="titre"><u>Consulter mes dépenses</u></h3><br /><br />
    
    <?php
    // ----------------------affichage du N° employé---------------------------
    $nom=$_SESSION['nom'];
    $sql="SELECT e.noEmp FROM employe e where e.nom=:nom group by e.nom";
    $req=$connexion->prepare($sql);
    $reponse=$req->execute(array('nom'=>$nom));
    while($resultat=$req->fetch()){
        echo '<span class="info1">Votre numéro employé est '.$ref=$resultat['noEmp'].'.</span>';} ;
        echo '<br>';

    echo '<br>';
    // -------------------- affichage du tableau des dépenses ------------------------
    $sql="SELECT * FROM nortech.frais where noEmp='{$ref}'";
    $req=$connexion->prepare($sql);
    $reponse=$req->execute(array());
    ?>

    <table class="tabFrais">
        <thead>
            <tr>
                <th>N° Frais</th><th>Date de Frais</th><th>Montant</th><th>Motif</th><th>Autre motif</th>
            </tr>
        </thead>
    <tbody>
    <?php
    while ($resultat=$req->fetch()){
        echo '<tr>';
        echo '<td>'.$resultat['noFrais'].'</td><td>'.$resultat['dateFrais'].'</td><td>'.$resultat['montant'].'</td><td>'.$resultat['motif'].'</td><td>'.$resultat['autreMotif'].'</td>';
        echo'</tr>';
    }
    ?>
    </tbody>
    </table>


    <?php 
    $sql1="select * from nortech.frais where noEmp='{$ref}'";
    $req1=$connexion->prepare($sql1);
    $reponse1=$req1->execute(array());
    ?>
    <div class="listeFrais">
        <hr class="sautLigne">
        <?php
            while($resultat1=$req1->fetch()){
                echo '<li class="listeF"><p>
                    N° Frais: '.$resultat1['noFrais'].'<br>
                    Date de frais: '.$resultat1['dateFrais'].'<br>
                    Montant: '.$resultat1['montant'].'<br>
                    Motif: '.$resultat1['motif'].'<br>
                    Autre motif: '.$resultat1['autreMotif'].'</p></li><br>
                    <hr class="sautLigne">';
            }
        
        ?>
    </div>



    <?php
    //-------------------------Affichage du total des frais --------------------------
    $sql="SELECT sum(montant) from nortech.frais where noEmp='{$ref}'";
    $req=$connexion->prepare($sql);
    $reponse=$req->execute(array());
    $resultat=$req->fetch();
    echo '<br>';
    echo '<span class="info">La somme de vos dépenses est de '.$resultat['sum(montant)'].' €.</span>';

    echo '<br>';
    ?>
    <br>
    <div class="form-btn">
        <a href="espace_perso.php"><input class='retour' type="button" value="Retour à l'espace personnel" ></a>
    </div>

<?php 
    echo '<br /><br />';
    include('footer.php');
        }
?>
</body>
</html>