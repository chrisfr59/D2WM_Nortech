<footer>
	<div style="text-align: center;width:100%;background-color:#4DA91C;color: white; min-height: 80px;margin: 0; ">
	<p style="font-size: 17px;">NorTech c'est l'énergie...</p>
	</div>
</footer>