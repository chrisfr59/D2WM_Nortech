<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<link rel="stylesheet" href="css/resultatpiae.css">
<?php
session_start();
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
//use PhpOffice\PhpSpreadsheet\Worksheet\Protection;
use PhpOffice\PhpSpreadsheet\Style\Protection;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
else{
    require('../../paye/vendor/autoload.php');



$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$spreadsheet->getActiveSheet()->getProtection()->setSheet(true);
$spreadsheet->getSecurity()->setLockWindows(true);
$spreadsheet->getSecurity()->setLockStructure(true);
$spreadsheet->getSecurity()->setWorkbookPassword("CCSD");
$spreadsheet->getActiveSheet()->getProtection()->setPassword('CCSD');
$CP=explode(",",$_POST['adresse']);

$sheet
->setCellValue('A1', 'Bulletin de salaire du mois de '.substr($_POST['mois'],2).' '.date('Y'))

->setCellValue('A4', 'SALARIE')
->setCellValue('A5', 'N°Employé :')
->setCellValue('A6', 'Nom /prénom :')
->setCellValue('A7', 'Adresse : ')
->setCellValue('A8', 'CP/Ville : ')
->setCellValue('A9', 'Emploi')
->setCellValue('A10', 'Convention Collective Nationale de travail des Energies Renouvelables. Code NAF: 85.3 G')
->setCellValue('A12', 'SALAIRE MENSUEL BRUT')
->setCellValue('A13', 'Salaire mensualisé brut de base')
->setCellValue('A14', 'Heures complémentaires (jusqu\'à 45 h/sem)')
->setCellValue('A15', 'Heures sup. ou majorées (à partir de 46ème h/sem)')
->setCellValue('A16', 'Absences')
->setCellValue('A17', 'Conges payés')
->setCellValue('A18', 'Commission')
->setCellValue('A19', 'Prime')
->setCellValue('A20', 'TOTAL SALAIRE BRUT')
->setCellValue('A22', 'COTISATIONS SALARIALES')
->setCellValue('A23', 'CSG non imposable')
->setCellValue('A24', 'CSG+CRDS imposable')
->setCellValue('A25', 'Sécurité Sociale (maladie, vieillesse, veuvage)')
->setCellValue('A26', 'Prévoyance')
->setCellValue('A27', 'Retraite complémentaire')
->setCellValue('A28', 'Assurance chômage')
->setCellValue('A29', 'AGFF')
->setCellValue('A30', 'Total cotisations salariales')
->setCellValue('A32', 'SALAIRE NET')
->setCellValue('A38', 'Nombre de jours de congés payés : ')
->setCellValue('A44', 'Ce présent bulletin de paie doit être conservé sans limitation de durée ')
->setCellValue('C5', $_POST['noemp'])
->setCellValue('C6', $_POST['nom'].' '.$_POST['prenom'])
->setCellValue('B7', $CP[0] )
->setCellValue('B8', $CP[1])
->setCellValue('B9', $_POST['fonction'])

->setCellValue('E4', 'EMPLOYEUR')
->setCellValue('E5', 'N° URSSAF :')
->setCellValue('E6', 'Nom :')
->setCellValue('E7', 'Adresse :')
->setCellValue('E8', 'CP/Ville :')
->setCellValue('E38', $_POST['conges'])

->setCellValue('F12', 'Nombre d\'heures ')
->setCellValue('F13',$_POST['heures'])
->setCellValue('F14', '')
->setCellValue('F15', '')
->setCellValue('F16', '='.$_POST['absence'].'*7')
->setCellValue('F17', '')
->setCellValue('F18', '')
->setCellValue('F19', '')
->setCellValue('F20', '')
->setCellValue('F21', '')
->setCellValue('F22', 'Taux en %')
->setCellValue('F23', '6.8')
->setCellValue('F24', '2.9')
->setCellValue('F25', '7.3')
->setCellValue('F26', '1.15')
->setCellValue('F27', '3.1')
->setCellValue('F28', '0.95')
->setCellValue('F29', '0.8')

->setCellValue('G5', '24ERG7')
->setCellValue('G6', 'NORTECH')
->setCellValue('G7', '41-43 rue du Faubourg Saint-Honoré')
->setCellValue('G8', '75 008 PARIS')
->setCellValue('H13', $_POST['taux'])
->setCellValue('H12', 'Taux horaire brut')
->setCellValue('H16', $_POST['taux'])

->setCellValue('H22', 'Base')
->setCellValue('H23', '=J20*0.9825')
->setCellValue('H24', '=J20*0.9825')
->setCellValue('H25', '=J20')
->setCellValue('H26', '=J20')
->setCellValue('H27', '=J20')
->setCellValue('H28', '=J20')
->setCellValue('H29', '=J20')
->setCellValue('H36', date("d-m-Y", strtotime($_POST['date'])))

->setCellValue('G36', 'Payé le :')
->setCellValue('G39', 'Signature de l\'employeur')


->setCellValue('J12', 'TOTAL')
->setCellValue('J13', '=F13*H13')
->setCellValue('J20', '=J13+J14+J15-J16+J17+J18+J19')
->setCellValue('J16', '=F16*H16')
->setCellValue('J17', $_POST['conges'])
->setCellValue('J18', $_POST['commission'])
->setCellValue('J19', $_POST['prime'])
->setCellValue('J22', 'TOTAL')
->setCellValue('J23', '=F23*H23/100')
->setCellValue('J24', '=F24*H24/100')
->setCellValue('J25', '=F25*H25/100')
->setCellValue('J26', '=F26*H26/100')
->setCellValue('J27', '=F27*H27/100')
->setCellValue('J28', '=F28*H28/100')
->setCellValue('J29', '=F29*H29/100')
->setCellValue('J30', '=J23+J24+J25+J26+J27+J28+J29')
->setCellValue('G32', '=J20-J30')
->setCellValue('H42', 'Paul LEROY')


;
//fusionner les cellules
$sheet->mergeCells("A1:J3");
$sheet->mergeCells("A10:J10");
$sheet->mergeCells("A4:D4");
$sheet->mergeCells("A44:J44");
$sheet->mergeCells("E4:J4");
$sheet->mergeCells("F12:G12");
$sheet->mergeCells("H12:I12");
$sheet->mergeCells("F13:G13");
$sheet->mergeCells("H13:I13");
$sheet->mergeCells("F14:G14");
$sheet->mergeCells("H14:I14");
$sheet->mergeCells("F15:G15");
$sheet->mergeCells("H15:I15");
$sheet->mergeCells("F16:G16");
$sheet->mergeCells("H16:I16");
$sheet->mergeCells("F17:G17");
$sheet->mergeCells("H17:I17");
$sheet->mergeCells("F18:G18");
$sheet->mergeCells("H18:I18");
$sheet->mergeCells("F19:G19");
$sheet->mergeCells("H19:I19");
$sheet->mergeCells("G39:I39");
$sheet->mergeCells("C5:D5");
$sheet->mergeCells("C6:D6");
$sheet->mergeCells("B7:D7");
$sheet->mergeCells("B8:D8");
$sheet->mergeCells("B9:D9");
$sheet->mergeCells("G32:J33");
$sheet->mergeCells("A32:F33");
$sheet->mergeCells("A38:D38");




// centrer le texte dans la cellulle
$style = array('alignment' => array(
    'horizontal' => Alignment::HORIZONTAL_CENTER,
    'vertical' => Alignment::VERTICAL_CENTER,
    )
);
$sheet->getStyle("A1:J3")->applyFromArray($style);
$sheet->getStyle("A10:J10")->applyFromArray($style);
$sheet->getStyle("A4:D4")->applyFromArray($style);
$sheet->getStyle("A44:J44")->applyFromArray($style);
$sheet->getStyle("E4:J4")->applyFromArray($style);
$sheet->getStyle("F12:J20")->applyFromArray($style);
$sheet->getStyle("F22:J30")->applyFromArray($style);
$sheet->getStyle("G39:I40")->applyFromArray($style);
$sheet->getStyle("G32:J33")->applyFromArray($style);
$sheet->getStyle("A32:F33")->applyFromArray($style);
$sheet->getStyle("A38")->applyFromArray($style);


$left = array('alignment' => array(
    'horizontal' => Alignment::HORIZONTAL_LEFT,
    
    )
);

$sheet->getStyle("E38")->applyFromArray($left);
$sheet->getStyle("C5")->applyFromArray($left);


// bordures colorées
$styleArray = [
    'borders' => [
        'outline' => [
            'borderStyle' => Border::BORDER_THICK,
            'color' => ['argb' => '008000'],
        ],
    ],
];
$sheet->getStyle('A1:J3')->applyFromArray($styleArray);
$sheet->getStyle('A4:D9')->applyFromArray($styleArray);
$sheet->getStyle('E4:J9')->applyFromArray($styleArray);
$sheet->getStyle('A12:J20')->applyFromArray($styleArray);
$sheet->getStyle('A22:J30')->applyFromArray($styleArray);
$sheet->getStyle('A32:J32')->applyFromArray($styleArray);
$sheet->getStyle('G39:I42')->applyFromArray($styleArray);
$sheet->getStyle('A1:J44')->applyFromArray($styleArray);
$sheet->getStyle('A32:J33')->applyFromArray($styleArray);


// centrer le texte dans la cellulle
$sheet->getStyle("A1:J3")->applyFromArray($style);
$sheet->getStyle("A10:J10")->applyFromArray($style);
$sheet->getStyle("A4:D4")->applyFromArray($style);
$sheet->getStyle("A44:J44")->applyFromArray($style);
$sheet->getStyle("E4:J4")->applyFromArray($style);
$sheet->getStyle("F12:J20")->applyFromArray($style);
$sheet->getStyle("F22:J30")->applyFromArray($style);
$sheet->getStyle("G39:I42")->applyFromArray($style);

// coloration cellule

$sheet->getStyle("A1:J3")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('8FBC8F');
$sheet->getStyle("A10:J11")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('8FBC8F');
$sheet->getStyle("A21:J21")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('8FBC8F');
$sheet->getStyle("A31:J31")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('8FBC8F');
$sheet->getStyle("A33:J35")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('8FBC8F');
$sheet->getStyle("A44:J44")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('8FBC8F');
$sheet->getStyle("A36:E43")->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setARGB('8FBC8F');


//marges de la page pour impression sur 1 seule page
$sheet->getPageMargins()->setTop(1);
$sheet->getPageMargins()->setRight(0.65);
$sheet->getPageMargins()->setLeft(0.65);
$sheet->getPageMargins()->setBottom(1);

//arrondi a 2 chiffres apres la virgule
$sheet->getStyle('J23:J30')->getNumberFormat()
    ->setFormatCode(NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED2);

$sheet->getStyle('G32')->getNumberFormat()
    ->setFormatCode(NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED2);

$writer = new Xlsx($spreadsheet);
$writer->save('../../paye/'.$_POST['noemp'].'-'.substr($_POST['mois'],0,2).'-'.date("Y").'.xlsx');


$nav_en_cours = 'espace_perso';

include('header.php');



echo '<h3><u>Récapitulatif des saisies</u></h3><br>';
echo '<div class="corp">';
echo '<div class="resultat">';

    echo '<div>';
        echo 'Nom et prenom : '. $_POST['nom'].' '.$_POST['prenom'];
    echo '</div>';

    echo '<div>';
        echo 'Adresse : '.$CP[0];
    echo '</div>';

    echo '<div>';
        echo 'CP et ville : '.$CP[1];
    echo '</div>';

    echo '<div>';
        echo 'Fonction : '.$_POST['fonction'];
    echo '</div>';

    echo '<div>';
        echo 'Nombre d\'heures travaillées : '.$_POST['heures'];
    echo '</div>';

    echo '<div>';
        echo 'Taux horaire : '.$_POST['taux'];
    echo '</div>';

    echo '<div>';
        echo 'Commission : '.$_POST['commission'];
    echo '</div>';

    echo '<div>';
        echo 'Prime : '.$_POST['prime'];
    echo '</div>';

    echo '<div>';
        echo 'Congés pris : '.$_POST['conges'];
    echo '</div>';

    echo '<div>';
        echo 'Date du paiement : '.$_POST['date'];
    echo '</div><br>';
    
    echo '<div>';
        echo  'Pour voir un aperçu cliquez <a href="../../paye/'.$_POST['noemp'].'-'.substr($_POST['mois'],0,2).'-'.date("Y").'.xlsx">ici</a>';
        echo '<br>';
        echo 'Si il y a des erreurs cliquez <a href="javascript:history.back()">ici</a>';
        echo '<br>';
    echo '</div><br>';  

    echo '<div>';
        echo '<a  href="redirection.php?section=employe" role="button"><input style="margin-bottom: 4% !important; background-color: #4DA91C !important; color: white !important; padding: 1.5px !important;" type="submit" name="btnSubmit" class="valider" value="Valider" /></a>';
    echo '</div>';
echo '</div>';
echo '</div><br /><br />';

include('footer.php');
}
?>