<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!--css Bootstrap-->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src="main.js"></script>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

        <!--Fontawesom-->
        <link rel="stylesheet" href="css/font-awesome.min.css">

        <!--Animated CSS-->
        <link rel="stylesheet" type="text/css" href="css/animate.min.css">

        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <!--Bootstrap Carousel-->
        <link type="text/css" rel="stylesheet" href="css/carousel.css" />

        <link rel="stylesheet" href="css/isotope/style.css">

        <!--Main Stylesheet-->
        <link href="css/style.css" rel="stylesheet">
        <!--Responsive Framework-->
        <link href="css/responsive.css" rel="stylesheet">
        <link href="css/employe.css" rel="stylesheet">
</head>

<?php
$nav_en_cours = 'employe';
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('../../index.php');
                </script>";
}
include('header.php'); 
$sql="select noServ, service from service";
$req=$connexion->query($sql);

$sql2="select distinct fonction from employe";
$req2=$connexion->query($sql2);
?>

<body>

<div class="container">
    <div class=row>
        <div class="col-md-3"></div>
        <div class="col-md-6">
            <fieldset class="emp">
            <legend><u>Ajouter Employé</u></legend>
                <form class="border border-success p-5" method="POST" name="add_user" action="../controller/createEmploye.action.php" required>

                        <label for="EmailType">Statut: </label>
                        <select name="EmailType" id="EmailType">
                            <option value="0">Interne</option>
                            <option value="1">Externe</option>
                        </select><br>

                        <label for="nom ">Nom:</label>
                        <input type="text" id="tentacles" name="nom"  class="input" placeholder="" required>
                    
                        <label for="prenom" >prenom:</label>
                        <input type="text" id="textInput" class="input" placeholder="" name="prenom" required>

                        <label for="nais">naissance:</label>
                        <input type="date" id="textInput" class="input" placeholder="" name="nais" required>

                        <label for="tel">tel:</label>
                        <input type="text" id="tentacles" name="tel"  class="input" placeholder="" required>
                    
                        <label for="adresse" >Adresse:</label>
                        <input type="text" id="textInput" class="input" placeholder="" name="adresse" required>

                        <label for="emb">embauche:</label>
                        <input type="date" id="tentacles" name="emb" class="input" placeholder="" required>

                        <label for="fonction">Fonction: </label>
                        <select name="fonction" id="fonction" required>
                            <option value="">--Selectionnez une fonction--</option>
                                <?php
                                while($reponse2=$req2->fetch()){
                                    echo '<option value="'.$reponse2['fonction'].'">'.ucwords(strtolower($reponse2['fonction'])).'</option>';
                                }
                                ?>
                            <option value="Autre">Autre</option>
                        </select>
                        <br>

                        <span id="fonctionA" style="display: none;">
                            <label for="fonctionA">Entrez une nouvelle fonction: </label>
                            <input type="text" id="Autre" name="fonctionA" class="input" placeholder="Nouvelle Fonction"></textarea>
                            <br><br>
                        </span>

                        <script type="text/javascript">
                            var select = document.getElementById('fonction');
                            select.onchange = function(){
                                var span = document.getElementById('fonctionA');
                                if(this.value == 'Autre'){
                                    span.style.display='block';
                                }
                                else{
                                    span.style.display ='none'; 
                                } 
                            }
                        </script>

                        <label for="tauxH ">Taux Horaire:</label>
                        <input type="number" step="0.01" id="tentacles" name="tauxH"  class="input" placeholder="" min="9.88" required>

                        <label for="noServ">Service: </label>
                        <select name="service" id="service">
                            <option value="">--Selectionnez un service--</option>
                                <?php 
                                while($reponse=$req->fetch()){
                                    echo '<option value="'.$reponse['noServ'].'">'.ucwords(strtolower($reponse['service'])).'</option>';
                                }
                                ?>
                        </select><br><br />
                        
                <input class="submit envoyer" type="submit" value="Creer">
                <a href="redirection.php?section=employe"><input class="button envoyer" type="button" value="Retour" ></a>
            </form>
            </fieldset>
        </div>
        <div class="col-md-3"></div>
    </div>
</div><br /><br />

<?php include('footer.php') ?>
</body>
</html>