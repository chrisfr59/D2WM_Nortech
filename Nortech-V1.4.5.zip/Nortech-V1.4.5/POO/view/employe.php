<?php $nav_en_cours = 'employe'; ?>
<!DOCTYPE html>
<html lang="fr">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="CSS/main.css">
        <link href="css/style.css" rel="stylesheet">
        <!--Responsive Framework-->
        <link href="css/responsive.css" rel="stylesheet">
        <title>Site Nortech</title>
    </head>

    <body>
        <?php
            session_start();
            if(empty($_SESSION)){
                echo "<script type='text/javascript'>document.location.replace('index.php');
                            </script>";
            }
            include('header.php');

            //session_start();
            unset($_SESSION['mail']);
            unset($_SESSION['sujet']);
            unset($_SESSION['message']);
            unset($_SESSION['CV']);
            unset($_SESSION['Envoi']);
            unset($_SESSION['nomUp']);
            unset($_SESSION['prenomUp']);
            //Insertion de la bannière et de la navigation


            if(!empty($_GET['recherche'])){
                if($_GET['recherche']=='Fonction'){
                    $sql='SELECT *,DATE_FORMAT(embauche,"%d-%m-%Y"),DATE_FORMAT(naissance,"%d-%m-%Y") from nortech.employe e, nortech.service s where e.noServ=s.noServ and fonction like '.$_GET['Fonction'].' and active=1 order by noEmp';
                }
                else if($_GET['recherche']=='Service'){
                    $sql='SELECT *,DATE_FORMAT(embauche,"%d-%m-%Y"),DATE_FORMAT(naissance,"%d-%m-%Y") from nortech.employe e, nortech.service s where e.noServ=s.noServ and e.noServ like '.$_GET['Service'].' and active=1 order by noEmp';
                }
                else{
                    $sql='SELECT *,DATE_FORMAT(embauche,"%d-%m-%Y"),DATE_FORMAT(naissance,"%d-%m-%Y") from nortech.employe e, nortech.service s where e.noServ=s.noServ and active=1 order by noEmp';
                }
            }
            else{
                $sql='SELECT *,DATE_FORMAT(embauche,"%d-%m-%Y"),DATE_FORMAT(naissance,"%d-%m-%Y") from nortech.employe e, nortech.service s where e.noServ=s.noServ and active=1 order by noEmp';
            }
            //Préparation de la requête SQL en utilisant la variable $connexion
            $req=$connexion->prepare($sql);
            //execuction de la requête avec enregistrement des résultats dans la variable $reponse
            //(boolean qui prend deux valeurs : 1 pour execute=ok et 0 pour execute=ko)
            $reponse=$req->execute(array());

            $sql2="select noServ, service from service";
            $req2=$connexion->query($sql2);

            $sql3="select distinct fonction from employe";
            $req3=$connexion->query($sql3);

            $req4=$connexion->query($sql);
        ?>

        <ul class="niveau1">
            <li class="tri"><a href="redirection.php?section=employe">recherche</a>
                <ul class="niveau2">
                    <li class="plus"><a href="#">Fonction</a>
                        <ul class="niveau3">
                            <?php
                                while($reponse3=$req3->fetch()){
                                    echo '<li class="dernier"><a href="employe.php?recherche=Fonction&Fonction=\''.$reponse3['fonction'].'\'">'.ucwords(strtolower($reponse3['fonction'])).'</a></li>';
                                }
                            ?>
                        </ul>
                    </li>        
                    <li class="plus"><a href="#">Service</a>
                        <ul class="niveau3">
                            <?php
                                while($reponse2=$req2->fetch()){
                                    echo '<li class="dernier"><a href="employe.php?recherche=Service&Service='.$reponse2['noServ'].'">'.ucwords(strtolower($reponse2['service'])).'</a></li>';
                                }
                            ?>
                        </ul>
                    </li>
                </ul>
            </li>
        </ul>
        <li class="buttonEmp"><a href="createEmploye.php">Ajouter un employé</a></li><br>
        <h3 class="titre">Informations du personnel</h3>
        <form id="mail" name ="mail" method="post" action="mail.php">
            <div class="listeR">
                <br><li class="listeRes"><input type="checkbox" name="all" id="all"> Pour sélectionner tous les employés.</li>
            </div>
            <table class=tabEmp>
                <thead>
                    <tr>
                        <th><input type="checkbox" name="allCheck" id="allCheck"></th>
                        <th>Numéro d'employé</th>
                        <th>Nom</th>
                        <th>Prenom</th>
                        <th>Adresse</th>
                        <th>Fonction</th>
                        <th>Supérieur</th>
                        <th>Taux Horaire</th>
                        <th>Commission</th>
                        <th>Naissance</th>
                        <th>Téléphone</th>
                        <th>Service</th>
                        <th>Prime</th>
                        <th>Embauche</th>
                        <th>E-mail</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $m=0;
                    while($resultat=$req->fetch()){
                        echo '<tr>';
                        echo '<td><input type="checkbox" name="mail[]" class="checkbox" id="mail'.($m+1).'" value="'.$resultat['mail'].'"></td>
                            <td>'.$resultat['noEmp'].'</td>
                            <td>'.$resultat['nom'].'</td>
                            <td>'.$resultat['prenom'].'</td>
                            <td>'.$resultat['adresse'].'</td>
                            <td>'.$resultat['fonction'].'</td>
                            <td>'.$resultat['sup'].'</td>
                            <td>'.$resultat['tauxH'].'</td>
                            <td>'.$resultat['comm'].'</td>
                            <td>'.$resultat['DATE_FORMAT(naissance,"%d-%m-%Y")'].'</td>
                            <td>'.$resultat['tel'].'</td>
                            <td>'.$resultat['service'].'</td>
                            <td>'.$resultat['prime'].'</td>
                            <td>'.$resultat['DATE_FORMAT(embauche,"%d-%m-%Y")'].'</td>
                            <td>'.$resultat['mail'].'</td>
                            <td><a class="buttonEmpTab" type="button" href="update_employe.php?id='.$resultat['noEmp'].'">Update</a>
                            <a class="buttonEmpTab" type="button"  href="../controller/deletejs.php?id='.$resultat['noEmp'].'">Delete</a>
                            <a class="buttonEmpTab" type="button"  href="formFichePaie.php?id='.$resultat['noEmp'].'">Paye</a></td>';
                        echo'</tr>';
                        $m++;
                    }
                    ?>
                </tbody>
            </table>
            <script type="text/javascript">
                var tailleTableau = <?php echo json_encode($m);?>;
                var checkAll = document.getElementById('allCheck');
                checkAll.onclick = function(){
                    if(checkAll.checked==true){
                        for (i=1;i<=tailleTableau;i++){
                            document.getElementById("mail"+i).checked = true;
                        }
                    }
                    else{
                        for (i=1;i<=tailleTableau;i++){
                            document.getElementById("mail"+i).checked = false;
                        }
                    }
                }
                var checkAll2 = document.getElementById('all');
                checkAll2.onclick = function(){
                    if(checkAll2.checked==true){
                        for (i=1;i<=tailleTableau;i++){
                            document.getElementById("mail"+i).checked = true;
                        }
                    }
                    else{
                        for (i=1;i<=tailleTableau;i++){
                            document.getElementById("mail"+i).checked = false;
                        }
                    }
                }
            </script>
            <br>
            <input class="submitEmp" type="submit" name="Envoi" value="Envoyer Mail">
            <input class="submitEmp" type="submit" name="CV" value="Consulter CV">
            <div class="listeR">
                <hr class="retour">
                <?php
                while($resultat=$req4->fetch()){
                    echo '<li class="listeRes"><p> '.$resultat['noEmp'].' - '.$resultat['nom'].' - '.$resultat['prenom'].'<br><br>

                        Supérieur: '.$resultat['sup'].'<br>
                        Fonction: '.$resultat['fonction'].'<br>
                        Service: '.$resultat['service'].'<br>
                        Mail: '.$resultat['mail'].'<br>
                        Tél: '.$resultat['tel'].'<br>
                        Taux Horaire: '.$resultat['tauxH'].'<br>
                        Commission: '.$resultat['comm'].'<br>
                        Prime: '.$resultat['prime'].'<br>
                        Adresse: '.$resultat['adresse'].'<br>
                        Date de naissance: '.$resultat['DATE_FORMAT(naissance,"%d-%m-%Y")'].'<br>
                        Date d\'embauche: '.$resultat['DATE_FORMAT(embauche,"%d-%m-%Y")'].'</p></li><br>
                        <li class="listeRes"><p><a class="buttonEmpTab" type="button" href="update_employe.php?id='.$resultat['noEmp'].'">Update</a>
                        <a class="buttonEmpTab" type="button"  href="../controller/deletejs.php?id='.$resultat['noEmp'].'">Delete</a>
                        <a class="buttonEmpTab" type="button"  href="formFichePaie.php?id='.$resultat['noEmp'].'">Paye</a>
                        <a class="buttonEmpTab" type="button"  href="mail.php?action=mail&mail='.$resultat['mail'].'">Envoyer mail</a>
                        <a class="buttonEmpTab" type="button"  href="mail.php?action=CV&mail='.$resultat['mail'].'">Consulter CV</a></p></li>
                        <hr class="retour">';
                }
                ?>
            </div>
        </form>
        <br><br>
        <?php
        include('footer.php');
        ?>

    </body>

</html>