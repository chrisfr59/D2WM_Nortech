<?php $nav_en_cours = 'offre_emploi'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    

    <title>Document</title>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>

<!--Fontawesom-->
<link rel="stylesheet" href="css/font-awesome.min.css">

<!--Animated CSS-->
<link rel="stylesheet" type="text/css" href="css/animate.min.css">

<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">
<!--Bootstrap Carousel-->
<link type="text/css" rel="stylesheet" href="css/carousel.css" />

<link rel="stylesheet" href="css/isotope/style.css">

<!--Main Stylesheet-->
<link href="css/style.css" rel="stylesheet">
<!--Responsive Framework-->
<link href="css/responsive.css" rel="stylesheet">
<link href="css/emploi.css" rel="stylesheet">
    
</head>


<body>
    <?php
    session_start();
    if(empty($_SESSION)){
        echo "<script type='text/javascript'>document.location.replace('index.php');
                    </script>";
    }
        include('header.php');
    ?>
     


    <div class=formulaire>
        <div class='recherche'>
        <form method ="GET" action="recherche.php">
        	<h3>Rechercher une annonce</h3><br>                                  
            <input type="search" name="terme" placeholder="Saisir le titre ou la ville"/><br><br>                                  
            <input id="search" type= "submit" name="s" value="Rechercher" required/> 
            <input id="effacer" type="reset" value="Effacer" />                         
        </form>
    </div><br>
        <a  href="ajouter_annonce.php?section=offre"><input id="ajouter" type="button" value="Ajouter une offre d'emploi"></a><br><br>
    </div>
    <?php

      $sql='SELECT * FROM nortech.annonce';
      // préparation de la requête SQL en utilisant la variable $connexion
      $req=$connexion->prepare($sql);
      //execution de la requête avec enregistrement des résultats dans la variable $reponse (boolean qui prend deux valeurs 1 pour execute=ok et 0 pour execute=ko)
      $reponse=$req->execute(array());
        
        $nume=$reponse+1;
        $annonce='annonce';
        $numannonce=1;
        while($resultat=$req->fetch()){
            echo '<div class="offre"';
            echo '<tr>';
            echo '<td ><h4>Offre N° '.$resultat['noAnnonce'].'</h4><h1 class="titre">'.$resultat['titre'].'</h1><h4>Service : </h4>'.$resultat['service'].'</td><br>
            <h4 class="date">Date :</h4> 
            <td class="date">'.date("d-m-Y", strtotime($resultat['dateAnnonce'])).'</td><br>
            <h4 class="ville">Ville :</h4>
            <td class="ville">'.$resultat['ville'].'</td><br>
           <h4 class="entreprise"> Entreprise : </h4>
           <td ><div>
           Rejoignez les équipes de Nortech pour concevoir et intégrer les solutions innovantes de demain. <br><br>
           Nous accompagnons au quotidien les entreprises et les organisations dans leurs enjeux de transformation industrielle et digitale.<br> Notre ambition : le faire avec vous.

Parce que l’humain est au cœur de notre stratégie, nous pouvons offrir à chacun un cadre professionnel stimulant, <br>collaboratif et ouvert sur l\'avenir.<br><br>

Parce que votre talent mérite notre engagement, Créons ensemble la différence !
       </div></td><br><br>';
            echo '<button id="plus" title="Afficher le div" onclick="afficher_div_masque(',$numannonce,')" style="text-align: center; font-weight: bold;">Plus d\'infos</button>
            <div id="',$numannonce,'"style="display:none;"><br> ';
            echo '<td><br><h4 class="entreprise">Description : </h4>',nl2br($resultat['description']),'</td></div>';
            echo '</tr><br><br>';
			echo '<div class="bouton">';
            echo '<div>';
            echo '<a href="postuler.php?section=Offre_d_emploi&id=5000"><input id="postuler" type="button" value="Postuler"></a>';
            echo '</div>';

            echo '<div>';
            echo '<a href="update.php?section=offre&noffre='.$resultat['noAnnonce'].'"><input id="modifier" type="button" value="Modifier une offre d\'emploi" ></a>';
            echo '<a  href="supprimer_annonce.php?section=offre&noffre='.$resultat['noAnnonce'].'"><input id="supprimer" type="button" value="Supprimer une offre d\'emploi"></a>';
         
            echo'</div>';

            echo'</div>';
            echo '</div><br>';
            $numannonce++;
        }
        
    ?>
  


<?php
include('footer.php');
?>
<script type="text/javascript" src="js/nortechcommon.js"></script>
</body>

</html>








    