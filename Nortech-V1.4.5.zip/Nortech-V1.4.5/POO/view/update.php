<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Nortech</title>
    <!-- Font Awesome -->
    <!-- Bootstrap core CSS -->
    <!-- Your custom styles (optional) -->
    <link href="css/annonce.css" rel="stylesheet">
</head>

<body>
<?php
//appeler la connexion à la BDD
session_start();
  if(empty($_SESSION)){
      echo "<script type='text/javascript'>document.location.replace('index.php');
                  </script>";
  }


//récupération de la section : service/employé ou user
if(isset($_GET['section'])){
	$section=$_GET['section'];
}else{
	echo "<script type='text/javascript'>document.location.replace('redirection.php');
                alert('Cette est interdite !');
                </script>";
}

if($section=='offre'){
    $nav_en_cours = 'offre_emploi';
    include('header.php');
    if($section=='offre'){
        $id=$_GET['noffre'];
    
        $sql='select * from nortech.annonce where noAnnonce= :id';
        // préparation de la requête SQL en utilisant la variable $connexion
        $req=$connexion->prepare($sql);
        //execution de la requête avec enregistrement des résultats dans la variable $reponse (boolean qui prend deux valeurs 1 pour execute=ok et 0 pour execute=ko)
        $reponse=$req->execute(array('id'=>$id));
        //enregistrement des valeurs retournés par la requête dans la variable $resultat
        $resultat=$req->fetch();
    }
}
    ?>

    <!--Mettre à jour une offre-->

    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <a href="redirection.php?section=offreemploi"><i
                style="margin-right: 0.5em; color: black;" class="fa fa-arrow-left fa-2x rotate-vert-center" aria-hidden="true"></i></a>

                <fieldset class="annonce">
                    <legend><u>Modifier une annonce</u></legend>
                        <form id="contact-form" name="contact-form" action="traitement_offre.php?section=offre&action=update&id=<?php echo $id;?>" method="POST">

                        <input type="text" id="titre" name="titre" class="form-control" value="<?php echo $resultat['titre'];?>" required><br />

                        <input type="number" id="noannonce" name="noannonce" class="form-control" value="<?php echo $resultat['noAnnonce'];?>" readonly><br />

                        <select class="browser-default custom-select" name="ville" id="noserv">
                            <option value="">Choisir la Ville</option>
                            <option value="Paris">PARIS</option>
                            <option value="Seclin">SECLIN</option>
                            <option value="Roubaix">ROUBAIX</option>
                            <option value="Villeneuve d'ascq">VILLENEUVE D'ASCQ</option>
                            <option value="Lille">LILLE</option>
                            <option value="Roubaix">ROUBAIX</option>
                        </select><br /><br />

                        <textarea type="text" id="descrip" name="descrip" cols=45 rows=10 class="form-control md-textarea " placeholder="Description de l'annonce" required><?php echo $resultat['description'];?></textarea><br />

                        <select class="browser-default custom-select" name="service" id="noserv">
                            <option value="">Choisir le service</option>
                            <option value="Drirection">Direction</option>
                            <option value="Logistique">Logistique</option>
                            <option value="Ventes">Ventes</option>
                            <option value="Formation">Formation</option>
                            <option value="Informatique">Informatique</option>
                            <option value="Comptable">Comptable</option>
                            <option value="Technique">Technique</option>
                            <option value="RH">RH</option>
                        </select><br /><br />

                        <button class="btn btn-green my-4 waves-effect z-depth-0 envoyer" type="submit" name="envoi">Modifier</button>
                        <button class="btn btn-grey lighten-1 float-right my-4 waves-effect z-depth-0 envoyer" type="reset">Effacer</button>
                
                        </form>
                </fieldset>
                </div>
            <div class="col-md-3"></div>
        </div>
    </div><br /><br />

<?php include('footer.php') ?>

    <!-------------------------------------modif Jonathan---------------------------------------------------------------------->



    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
</body>

</html>