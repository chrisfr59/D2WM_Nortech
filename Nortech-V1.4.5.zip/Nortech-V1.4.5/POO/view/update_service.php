<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
$nav_en_cours ='service';
include('header.php');
$numServ=$_GET['numServ'];
        $sql='select * from nortech.service where noServ= :numServ';
        // préparation de la requête SQL en utilisant la variable $connexion
        $req=$connexion->prepare($sql);
        //execution de la requête avec enregistrement des résultats dans la variable $reponse (boolean qui prend deux valeurs 1 pour execute=ok et 0 pour execute=ko)
        $reponse=$req->execute(array('numServ'=>$numServ));
        //enregistrement des valeurs retournés par la requête dans la variable $resultat
        $resultat=$req->fetch();
      
        
       /* $sql='select * from nortech.service where noServ= :par';
        // préparation de la requête SQL en utilisant la variable $connexion
        $req=$connexion->prepare($sql);
        //execution de la requête avec enregistrement des résultats dans la variable $reponse (boolean qui prend deux valeurs 1 pour execute=ok et 0 pour execute=ko)
        $reponse=$req->execute(array('par'=>$par));
        //enregistrement des valeurs retournés par la requête dans la variable $resultat
        $resultat=$req->fetch();
    //en cas de manipulation douteuse je redirige l'utilisateur vers index.php
        echo "<script type='text/javascript'>document.location.replace('index.php');
                    alert('Cette action est interdite !');
                    </script>";*/
    
?>

<article>
    <div style="text-align: center;width:100%; height: 60px;background-color:#4DA91C;color: white; margin:2% auto; padding:1.5rem ; ">
    <p style="font-size: 20px;"><b>Mise à jour de service N° <?php echo $resultat['noServ'];?></b> </p>
</div><br>
<div class="row">
<div class="col-xs-12 col-md-2"></div>
    <div class="col-xs-12 col-md-8">
<div class='formulaire_post' >
    <fieldset style="background-color: white;padding:1.6rem;text-align: center; "><br>
    
        <form name="update_service" method="POST" action="../controller/traitement.php?section=service&action=update&numServ=<?php echo $numServ;?>" >
        <div class="row">
                <div class="col-xs-12 col-md-2"></div>
                <div class="col-xs-12 col-md-4">
                    <label for="no_serv">N° Service </label>
                </div>
                <div class="col-xs-12 col-md-4">
                    <input type="text" name="no_serv" class="form-control" value="<?php echo $resultat['noServ'];?>" disabled="disabled" required>
                </div>
                <div class="col-xs-12 col-md-2"></div>
            </div><br>
            <div class="row">
                <div class="col-xs-12 col-md-2"></div>
                <div class="col-xs-12 col-md-4">
                    <label for="service"> Service </label>
                </div>
                <div class="col-xs-12 col-md-4">
                    <input type="text" name="service" class="form-control" value="<?php echo $resultat['service'];?>" required>
                </div>
                <div class="col-xs-12 col-md-2"></div>
            </div><br>
            <div class="row">
                <div class="col-xs-12 col-md-2"></div>
                <div class="col-xs-12 col-md-4">
                    <label for="ville"> Ville </label>
                </div>
                <div class="col-xs-12 col-md-4">
                    <input type="text" name="ville" class="form-control" value="<?php echo $resultat['ville'];?>" required>
                </div>
                <div class="col-xs-12 col-md-2"></div>
            </div><br>
            <div class="row">
                <div class="col-xs-12 col-md-6"></div>
                <div class="col-xs-12 col-md-2" style=" padding:0.6rem;">
                    <input type="submit" class="btn-success btn-lg" value="Envoyer">
                </div>
                <div class="col-xs-12 col-md-2" style=" padding:0.6rem;">
                    <input type="reset" class="btn-success btn-lg" value="Effacer">
                </div>
                <div class="col-xs-12 col-md-2"></div>
            </div>
        </form><br>
    </fieldset>
    </div>
    <div class="col-xs-12 col-md-2"></div>
    
</div>
    </article>