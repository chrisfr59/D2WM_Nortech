<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" media="screen" href="css/perso.css" />
    <script src="main.js"></script>
	<link rel="stylesheet" type="text/css" media="screen" href="css/cssUser.css" />
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
    <!--Fontawesom-->
<link rel="stylesheet" href="css/font-awesome.min.css">

<!--Animated CSS-->
<link rel="stylesheet" type="text/css" href="css/animate.min.css">

<!-- Bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container">
<section id="section1">
<button type="button" class="btn btn-secondary btn-xs lol"><a href="user.php">Retour</a></button>
<br>
<br>
    <h1 class="titre">Liste des dernières connexions</h1>
    
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Identifiant</th>
      <th scope="col">Nom</th>
      <th scope="col">Prenom</th>
      <th scope="col">Date connexion</th>
      <th scope="col">Adresse IP</th>
      <th scope="col">Poste</th>
    </tr>
  </thead>
  <tbody>
  <?php
  //demarrage de la session
  session_start();
  if(empty($_SESSION)){
      echo "<script type='text/javascript'>document.location.replace('index.php');
                  </script>";
  }
//connexion à la bdd
require('../common/modele/dbSingleton.php');
$dbi = DbSingleton::getInstance();
$connexion=$dbi->getConnection();
@$id=$_GET['id'];

 $sql="SELECT h.*,e.nom,e.prenom FROM historique h,employe e where h.identifiant=e.mail AND h.identifiant='$id'";
 //preparation de la rqt sql on utilisant la variable $connexion
 $req=$connexion->prepare($sql);
 //execution de la rqt avec eregistrement de resulat de la variable $reponse
 $reponse=$req->execute(array());
 while($result=$req->fetch()){
 echo '<tr>';
 echo '<td data-label="identifiant">'.$result['identifiant'].'</td>';
 echo '<td data-label="nom">'.$result['nom'].'</td>';
 echo '<td data-label="prenom">'.$result['prenom'].'</td>';
 echo '<td data-label="dataConnection">'.$result['dateConnection'].'</td>';
 echo '<td data-label="adresseIP">'.$result['adresseIP'].'</td>';
 echo '<td data-label="poste">'.$result['poste'].'</td>';
 echo '</tr>';
};
?>
    
</tbody>
</table>
</section>

</div>



<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
</body>
</html>