<?php
$nav_en_cours = 'offre_emploi';
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('index.php');
                </script>";
}
include('header.php');
echo '<br /><br />';
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Nortech</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/responsive.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/annonce.css" rel="stylesheet">
</head>

<body>

    <!--Formulaire ajout d'annonce-->

    <div class="container">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <a href="redirection.php?section=offreemploi"><i
                style="margin-right: 0.5em; color: black;" class="fa fa-arrow-left fa-2x rotate-vert-center" aria-hidden="true"></i></a>

                <fieldset class="annonce">
                    <legend><u>Ajouter une annonce</u></legend>
                    
                    <form id="contact-form" name="contact-form" action="traitement_offre.php?section=offre&action=ajouter" method="POST">

                        <input type="text" id="titre" name="titre" class="form-control" placeholder="Titre de l'annonce" required><br />

                        <input type="text" id="service" name="service" class="form-control" placeholder="Service"required><br />

                        <input type="date" id="date" name="date" class="form-control" required><br />

                        <input type="text" id="ville" name="ville" class="form-control" placeholder="Ville" required><br />

                        <textarea type="text" id="descrip" name="descrip" cols=45 rows=10 class="form-control md-textarea " placeholder="Description de l'annonce" required></textarea><br />

                        <button class="btn btn-green my-4 waves-effect z-depth-0 envoyer" type="submit" name="envoi">Envoyer</button>
                        <button class="btn btn-grey lighten-1 float-right my-4 waves-effect z-depth-0 envoyer" type="reset">Effacer</button>

                    </form>
                </fieldset>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div><br /><br />

<?php include('footer.php') ?>

    <!-- SCRIPTS -->
    <!-- JQuery -->
    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="js/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="js/mdb.min.js"></script>
</body>

</html>


