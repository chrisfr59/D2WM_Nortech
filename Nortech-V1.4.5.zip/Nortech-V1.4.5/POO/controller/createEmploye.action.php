<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('../view/index.php');
                </script>";
}
require('../common/modele/dbSingleton.php');
require('../common/modele/User.php');
require('../common/modele/Employe.php');
require('../common/modele/Email.php');
require('../common/factory/CommonTraitement.php');


$nom = $_POST['nom'];
$prenom = $_POST['prenom'];
$naissance = $_POST['nais'];
$tel = $_POST['tel'];
$adresse = $_POST['adresse'];
$embauche = $_POST['emb'];
$noServ = $_POST['service'];
if($_POST['fonction']=='Autre'){
    $fonction=strtoupper($_POST['fonctionA']);
}
else{
    $fonction=$_POST['fonction'];
}
$EmailType = $_POST['EmailType'];
$tauxH=$_POST['tauxH'];
if(!empty($_FILES)){
    $nomO=$_FILES['joinCV']['name'];
    $type=$_FILES['joinCV']['type'];
    $size=$_FILES['joinCV']['size'];
    $adrTmp=$_FILES['joinCV']['tmp_name'];
    $erreur=$_FILES['joinCV']['error'];
    $maxSize=10000000;
    $extensions_valides=array('pdf');
    $extension_upload=strtolower(substr(strrchr($nomO,'.'),1));
}


/*
*voici le controller du fomulaire (répertoire des views) "AjoutEmp.html" 
*
*
*/

/*création d'une nouveau employé à partir des valeur du formulaire 
*/
$newEmploye = New Employe($nom,$prenom,$adresse,$naissance,$tel,$embauche,$noServ,$fonction,$tauxH);

/*Création du nomero d'employé à partir du numéro de service récuperé du formulaire
*appel de la methode de création du numéro employé
*/
$noEmp = CommonTraitement::createnoEmp($newEmploye->getnoServ());

$sup = CommonTraitement::createSup($newEmploye);

$newEmploye->setSup($sup);

//ajout du numéro d'employé dans l'objet "newEmploye" par la méthode "setnoEmp"
$newEmploye->setnoEmp($noEmp);

//création du mail de l'employé à partir de l'objet "newEmploye" 
$mail= CommonTraitement::createMail($newEmploye->getNom(),$newEmploye->getPrenom(),$newEmploye->getnoEmp(),$EmailType);

//ajout du mail de l'employé dans l'objet "newEmploye" par la méthode "setMail"
$newEmploye->setMail($mail);

//modifie le numéro de téléphone vers la bonne syntaxe
$tel= CommonTraitement::normPhoneNumber($newEmploye);

//ajout du numéro de téléphone modifié dans l'objet "newEmploye" par la méthode "setTel"
$newEmploye->setTel($tel);

CommonTraitement::createSup($newEmploye);

$check= CommonTraitement::checkServEmpty($newEmploye);

$active= CommonTraitement::checkActive($newEmploye);

/*
*L'objet "newEmploye" est maintenant enrichit avec les nouvelles propriétés 
* à l'aide des methode de la fabrique à savoir
*	createnoEmp --> pour créer le numero d'employé
*	createMail --> pour lui créer son nouveau mail
*l'objet est ainsi pret à etre inserer en BDD
*après vérification que le numéro de téléphone
*ne soit pas déjà enregistré pour éviter les 
*doublons dans la BDD
*/
if(CommonTraitement::checkPhoneNumber($newEmploye)==false){
    if($check==false){
        if($newEmploye->getFonction()=='DIRECTEUR'){
            if(!empty($_FILES)){
                if(!CommonTraitement::verifCVJoin($erreur,$size,$maxSize,$extension_upload,$extensions_valides)){
                    CommonTraitement::verifCVJoin($erreur,$size,$maxSize,$extension_upload,$extensions_valides);
                    CommonTraitement::copyCVD($newEmploye);
                }
                else{
                    if(CommonTraitement::saveCV($newEmploye,$adrTmp)){
                        CommonTraitement::saveCV($newEmploye,$adrTmp);
                    }
                    else{
                        CommonTraitement::copyCVD($newEmploye);
                    }
                }
            }
            else{
                CommonTraitement::copyCVD($newEmploye);
            }
            CommonTraitement::insertEmp($newEmploye);
            CommonTraitement::createUserAccount($newEmploye);
            echo "<script type='text/javascript'>document.location.replace('../view/createEmploye.php');
                alert('L\'employé à bien été enregistré');
                </script>";
        }
        else{
            echo "<script type='text/javascript'>document.location.replace('../view/createEmploye.php');
                alert('Impossible d\'ajouter un employé dans un service sans directeur');
                </script>";
        }
    }
    else{
        if($newEmploye->getFonction()=='DIRECTEUR'){
            echo "<script type='text/javascript'>document.location.replace('../view/createEmploye.php');
                alert('Impossible d\'ajouter un second directeur dans le service');
                </script>";
        }
        else{
            if(!empty($_FILES)){
                if(!CommonTraitement::verifCVJoin($erreur,$size,$maxSize,$extension_upload,$extensions_valides)){
                    CommonTraitement::verifCVJoin($erreur,$size,$maxSize,$extension_upload,$extensions_valides);
                    CommonTraitement::copyCVD($newEmploye);
                }
                else{
                    if(CommonTraitement::saveCV($newEmploye,$adrTmp)){
                        CommonTraitement::saveCV($newEmploye,$adrTmp);
                    }
                    else{
                        CommonTraitement::copyCVD($newEmploye);
                    }
                }
            }
            else{
                CommonTraitement::copyCVD($newEmploye);
            }
            CommonTraitement::insertEmp($newEmploye);
            CommonTraitement::createUserAccount($newEmploye);
            echo "<script type='text/javascript'>document.location.replace('../view/redirection.php?section=employe');
                alert('L\'employé à bien été enregistré');
                </script>";
        }
    }
}else{
    if($active==1){
        echo "<script type='text/javascript'>document.location.replace('../view/createEmploye.php');
            alert('Employé déjà éxistant!');
            </script>";
    }
    else{
        $test=CommonTraitement::verifMemeNoServ($newEmploye);
        if($test){
            CommonTraitement::updateEmp($newEmploye, $test);
        }
        else{
            CommonTraitement::updateNoEmp($newEmploye, 'absence');
            CommonTraitement::updateNoEmp($newEmploye, 'consulter');
            CommonTraitement::updateNoEmp($newEmploye, 'frais');
            CommonTraitement::updateUser($newEmploye);
            CommonTraitement::copyCVD($newEmploye);
            CommonTraitement::updateEmp($newEmploye, $test);
        }   
        echo "<script type='text/javascript'>document.location.replace('../view/redirection.php?section=employe');
            alert('L\'employé à bien été enregistré');
            </script>";
    }
}    
?>