<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('../view/index.php');
                </script>";
}
else{
    require('../common/modele/dbSingleton.php');
$dbi = DbSingleton::getInstance();
$connexion=$dbi->getConnection();

    $noEmp=$_POST['noEmp'];
    $montant=$_POST['montant'];
    $date=$_POST['date'];
    $motif=$_POST['motif'];
    $autreMotif=$_POST['autreMotif'];

$sql='SELECT * FROM nortech.frais';
$req=$connexion->prepare($sql);
$reponse=$req->execute(array('id'=>$motif));
$sql='INSERT INTO `frais`(`motif`, `montant`, `dateFrais`, `noEmp`, `autreMotif`) VALUES (:id,:montant,:date,:noEmp, :autreMotif)';
	$req=$connexion->prepare($sql);
$reponse=$req->execute(array('id'=>$motif,'montant'=>$montant, 'date'=>$date,'noEmp'=>$noEmp ,'autreMotif'=>$autreMotif));
    
   if(!$reponse){
        echo "<script type='text/javascript'>document.location.replace('../view/redirection.php?section=espace_perso');
                    alert('l\'enregistrement de la note de frais a échoué ! Veuillez vérifier vos saisies.');
                    </script>";
        }else{
        echo "<script type='text/javascript'>document.location.replace('../view/consulter_frais.php');
                    alert('Note de frais enregistrée avec succès !');
                    </script>";
        }
    }    
?>