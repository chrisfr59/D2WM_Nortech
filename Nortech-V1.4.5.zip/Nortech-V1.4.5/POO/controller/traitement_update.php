<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('../view/index.php');
                </script>";
}
else{
    $nom=$_SESSION['nomUp'];
    $prenom=$_SESSION['prenomUp'];
    if($_POST['fonction']=='Autre'){
        $fonction=strtoupper($_POST['fonctionA']);
    }
    else{
        $fonction=$_POST['fonction'];
    }
    $tauxH=$_POST['tauxH'];
    if(empty($_POST['comm'])){
        $comm='null';
    }
    else{
        $comm=$_POST['comm'];
    }
    if(empty($_POST['prime'])){
        $prime='null';
    }
    else{
        $prime=$_POST['prime'];
    }
    if (empty($_POST['sup'])){
        $sup = 'null';
    }else{
        $sup=$_POST['sup'];
    }
    $mail=$_POST['mail'];
    $noServ=$_POST['service'];
    $tel=$_POST['tel'];
	$adresse=$_POST['adresse'];

    $req='update nortech.employe set adresse="'.$adresse.'", fonction="'.$fonction.'", sup='.$sup.', tauxH='.$tauxH.', comm='.$comm.', noServ='.$noServ.', tel="'.$tel.'", mail="'.$mail.'", prime='.$prime.' where nom="'.$nom.'" and prenom="'.$prenom.'"';    //echo $req;
    //connection bdd
    require('../common/modele/dbSingleton.php');
    $dbi = DbSingleton::getInstance();
    $connexion=$dbi->getConnection();
    $connexion->query($req);
	echo "<script type='text/javascript'>document.location.replace('../view/redirection.php?section=employe');
        alert('L\'employé a bien été mis à jour.');
        </script>";
}

?>