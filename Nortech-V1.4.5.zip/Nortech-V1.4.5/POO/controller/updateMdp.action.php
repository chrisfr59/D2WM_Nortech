<?php
session_start();
require('../common/modele/dbSingleton.php');
require('../common/modele/User.php');
require('../common/factory/CommonTraitement.php');
require('../common/modele/Connexion.php');
/*
*voici le controller du fomulaire (répertoire des views) "AjoutEmp.html" 
*
*
*/
$idUser = $_POST['idUser'];
$mdpUser  =$_POST['mdpUser'];
$cMdp = $_POST['cMdp'];

if(CommonTraitement::verifDemandeModif($idUser)){
    $id=CommonTraitement::recupId($idUser);
    CommonTraitement::updateMdp($id,$mdpUser,$cMdp,$idUser);
}
?>