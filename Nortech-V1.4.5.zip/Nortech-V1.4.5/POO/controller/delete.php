<?php
session_start();
if(empty($_SESSION)){
    echo "<script type='text/javascript'>document.location.replace('../view/index.php');
                </script>";
}
else{
    $req="update employe set active=0 where noEmp='{$_GET['id']}'";
    header("location: ../view/redirection.php?section=employe");
    require('../common/modele/dbSingleton.php');
    $dbi = DbSingleton::getInstance();
    $connexion=$dbi->getConnection();
    $test=$connexion->query($req);

    $resultat=$test->fetch();
}
?>