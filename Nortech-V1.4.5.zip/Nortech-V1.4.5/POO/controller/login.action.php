<?php
session_start();
require('../common/modele/dbSingleton.php');
require('../common/modele/User.php');
require('../common/factory/CommonTraitement.php');
require('../common/modele/Connexion.php');
include('traitement_login.php');

if(empty($_POST)){
    echo "<script type='text/javascript'>document.location.replace('../view/index.php');
                </script>";
}
else{
    $idUser = $_POST['idUser'];
$mpUser  =$_POST['mpUser'];

/*création d'une nouveau employé à partir des valeur du formulaire 
*/
$newConnexion = New Connexion($idUser,$mpUser);



//$newConnexion->setmdpUser($mdpUser);

$newConnexion->seConnecter($idUser, $mpUser);


$_SESSION['idUser']=$newConnexion->getIdUser();
}
?>