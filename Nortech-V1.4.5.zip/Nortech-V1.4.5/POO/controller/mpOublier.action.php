<?php
session_start();
require('../common/modele/dbSingleton.php');
require('../common/modele/User.php');
require('../common/factory/CommonTraitement.php');
require('../common/modele/Connexion.php');
if(empty($_POST)){
    echo "<script type='text/javascript'>document.location.replace('../view/index.php');
                </script>";
}
else{
    $IdUser = $_POST['modifIdUser'];

    if(CommonTraitement::verifExistId($IdUser)){
        $url = CommonTraitement::createUrl($IdUser);
        CommonTraitement::envoyerEmail($IdUser,$url);
        echo"<script type='text/javascript'>document.location.replace('../view/login.php');</script>";
    }
}
?>