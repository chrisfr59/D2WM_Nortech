<?php
class Connexion extends User{

    //constructeur
    public function __construct($idUser,$mdpUser){

        $this->idUser= $idUser;
        $this->mdp= $mdpUser;
    }

     //setters
     public function setIdUser($idUser){
        $this ->idUser = $idUser;
    }
    public function setmdpUser($mdpUser){
        $this ->mdp = $mdpUser;
    }

      //getters
      public function getIdUser(){
        return $this ->idUser;
    }
    public function getmdpUser(){
        return $this ->mdp;
    }

    public function seConnecter($idUser,$mpUser){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();     
        
        $sql2="SELECT * from utilisateur where identifiant='$idUser' AND  motPasse ='$mpUser'";
        $req2=$connexion->prepare($sql2);
        $reponse=$req2->execute(array('idUser'=>$idUser,'mp_user'=>$mpUser));
        //pointer sur la prmi�re colonne 
        $resultat= $req2 ->fetch();
        if($resultat['identifiant'] <> $idUser && $resultat['motPasse'] <> $mpUser){
            //Affichage d'un message d'erreur si l'identifiant ou le motPasse est incorrecte
            echo"<script type='text/javascript'>document.location.replace('../view/login.php');
                alert('l\'Identifiant ou le mot de passe sont incorrectes  !!');</script>";
        }else if($mpUser=='NORTECH'){
            $url = substr(CommonTraitement::createUrl($idUser),-20,20);
            echo"<script type='text/javascript'>document.location.replace('../view/updateMdp.php?id=$url');
                alert('Premi�re connexion : Veuillez modifier votre mot de passe');</script>";
        }else{
            $sql2="SELECT u.identifiant,e.active from utilisateur u,employe e 
            where u.identifiant='$idUser' and e.active=1 and e.noEmp=u.noEmp";
                $req2=$connexion->prepare($sql2);
                $reponse=$req2->execute(array());
                //pointer sur la prmi�re colonne 
                $resultat= $req2 ->fetch();     
                if($resultat['active'] == 0){
                    echo"<script type='text/javascript'>document.location.replace('../view/login.php');
                    alert('Le compte est d�sactiv� !!');</script>";
                }else{
                    $sql2="SELECT * from utilisateur where identifiant='$idUser' AND  motPasse ='$mpUser'";
                    $req2=$connexion->prepare($sql2);
                    $reponse=$req2->execute(array('idUser'=>$idUser,'mp_user'=>$mpUser));
                    //pointer sur la prmi�re colonne 
                    $resultat= $req2 ->fetch();
                    if(!$reponse){
                        echo "not ok";
                    }
                    else{
                        echo"<script type='text/javascript'>document.location.replace('../view/redirection.php');</script>"; 
                    }
                }
        }
}
}
?>