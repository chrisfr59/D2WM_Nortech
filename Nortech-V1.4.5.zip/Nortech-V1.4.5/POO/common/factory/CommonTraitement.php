<?php
final class CommonTraitement{
    
    /**
    *   Création du numéro d'employé 
    *   Paramètre d'entrée : $noServ
    *   Récupération du dernière employé du service $noServ
    *   Incrémentation du résultat de la requête pour création du $noEmp
    *   Si le service ne contient pas d'employé, alors set de la valeur de base à : $noServ suivit de 3 "0"
    *   Retour du $noEmp
    **/
    public static function createnoEmp($noServ){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql="select max(noEmp) from employe where noServ = $noServ";
        $req=$connexion->query($sql);
        $reponse=$req->fetch();
        if($reponse['max(noEmp)']==0){
            $noEmp=$noServ.'000';
        }
        else{
            $noEmp=$reponse['max(noEmp)'];
            $noEmp++;
        }
        return $noEmp;
    }

    public static function createSup(Employe $newObject){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql='SELECT * from employe where noServ = '.$newObject->getnoServ();
        $req=$connexion->query($sql);
        $resultat=$req->fetch();
        if($resultat==false){
            $sup="1000";
        }
        else{
            $sup=$newObject->getnoServ()."000";
        }
        return $sup;
    }

    /**
    *   Création du mail de l'employé 
    *   Paramètre d'entrée : $nom, $prenom, $noEmp
    *   Concaténation de $nom,$prenom et $noEmp avec un point "." comme sépartateur
    *   et suivit de "@nortech.com"
    *   Retour de $mail
    **/
    public static function createMail($nom, $prenom, $noEmp, $EmailType){
        $newEmail = new Email (strtolower($nom), strtolower($prenom), $noEmp, $EmailType);
        return $newEmail->getEmail();    
    }


    /*
    *Insertion d'un employé en BDD
    *
    *
    */
    public static function insertEmp(Employe $newObject){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql='INSERT INTO nortech.employe VALUES('.$newObject->getnoEmp().',"'.$newObject->getNom().'","'.$newObject->getPrenom().'","'.$newObject->getFonction().'",
        '.$newObject->getSup().','.$newObject->getTauxH().','.$newObject->getComm().',"'.$newObject->getNaiss().'","'.$newObject->getTel().'","'.$newObject->getMail().'",
        '.$newObject->getPrime().',"'.$newObject->getEmbauche().'",'.$newObject->getDepense().','.$newObject->getnoServ().','.$newObject->getActive().',"'.$newObject->getAdresse().'")';
        $req=$connexion->query($sql);

        //return $sql;
    }

    /*
    *Insertion de l'utilisateur en BDD
    */
    public static function createUserAccount(Employe $newObject){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql="INSERT INTO utilisateur (identifiant, motPasse,droits, noEmp) VALUES ('".$newObject->getMail()."', '".$newObject->getDefaultPwd()."',0, ".$newObject->getnoEmp().")";
        $req=$connexion->query($sql);
    }

    /*
    *Vérification de la présence de l'employé dans la BDD, via le numéro de téléphone.
    *
    */
    public static function checkPhoneNumber(Employe $newObject){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql='SELECT tel from employe where tel like "'.$newObject->getTel().'"';
        $req=$connexion->query($sql);
        return $resultat=$req->fetch();
    }

    /*
    *modifie le numéro de téléphone pour qu'il soit de la syntaxe suivante "0x.xx.xx.xx.xx"
    */
    public static function normPhoneNumber(Employe $newObject){
        $tabTel=explode(" ",$newObject->getTel());
        $tel="";
        $i=0;
        while($i<count($tabTel)){
            $tel.=$tabTel[$i];
            $i++;
        }
        $tabTel=explode(".",$tel);
        $tel="";
        $i=0;
        while($i<count($tabTel)){
            $tel.=$tabTel[$i];
            $i++;
        }
        $tabTel=explode("-",$tel);
        $tel="";
        $i=0;
        while($i<count($tabTel)){
            $tel.=$tabTel[$i];
            $i++;
        }
        $tel="0".substr($tel,-9,1).".".substr($tel,-8,2).".".
        substr($tel,-6,2).".".substr($tel,-4,2).".".substr($tel,-2);
        return $tel;
    }

    public static function checkServEmpty(Employe $newObject){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql='SELECT * from employe where noServ = '.$newObject->getnoServ();
        $req=$connexion->query($sql);
        $resultat=$req->fetch();
        if($resultat==false){
            $check=false;
        }
        else{
            $check=true;
        }
        return $check;
    }

    public static function checkActive(Employe $newObject){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql='SELECT active from employe where tel like "'.$newObject->getTel().'"';
        $req=$connexion->query($sql);
        $resultat=$req->fetch();
        return $resultat['active'];
    }

    public static function verifMemeNoServ(Employe $newObject){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sqlS='SELECT * from employe where tel like "'.$newObject->getTel().'"';
        $reqS=$connexion->query($sqlS);
        $resultatS=$reqS->fetch();
        if($resultatS['noServ']==$newObject->getnoServ()){
            return true;
        }
        else{
            return false;
        }
    }

    public static function updateEmp(Employe $newObject, $test){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sqlS='SELECT * from employe where tel like "'.$newObject->getTel().'"';
        $reqS=$connexion->query($sqlS);
        $resultatS=$reqS->fetch();
        if($test){
            $sql='UPDATE employe set fonction="'.$newObject->getFonction().'", embauche="'.$newObject->getEmbauche().'", 
            tauxH='.$newObject->getTauxH().', active=1, adresse="'.$newObject->getAdresse().'" where tel like "'.$newObject->getTel().'"';
        }
        else{
            $sql='UPDATE employe set noEmp='.$newObject->getnoEmp().', fonction="'.$newObject->getFonction().'", 
            sup='.$newObject->getSup().', embauche="'.$newObject->getEmbauche().'", tauxH='.$newObject->getTauxH().', mail="'.$newObject->getMail().'", 
            noServ='.$newObject->getnoServ().', active=1, adresse="'.$newObject->getAdresse().'" where tel like "'.$newObject->getTel().'"';

        }
        $req=$connexion->query($sql);
        
    }

    public static function updateNoEmp(Employe $newObject, $table){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sqlS='SELECT * from employe where tel like "'.$newObject->getTel().'"';
        $reqS=$connexion->query($sqlS);
        $resultatS=$reqS->fetch();
        $sql='UPDATE '.$table.' set noEmp='.$newObject->getnoEmp().' where noEmp='.$resultatS['noEmp'];
        $req=$connexion->query($sql);
    }

    public static function updateUser(Employe $newObject){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sqlS='SELECT * from employe where tel like "'.$newObject->getTel().'"';
        $reqS=$connexion->query($sqlS);
        $resultatS=$reqS->fetch();
        $sql='UPDATE utilisateur set noEmp='.$newObject->getnoEmp().', identifiant="'.$newObject->getMail().'" where noEmp='.$resultatS['noEmp'];
        $req=$connexion->query($sql);
        return $sql;
    }
    
    public static function updateMdp($idUser,$mdpUser,$cMdp,$id){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
                
        $sql3="SELECT * from utilisateur where identifiant='$idUser'";
        $req3=$connexion->prepare($sql3);
        $reponse3=$req3->execute(array('idUser'=>$idUser));
        //pointer sur la prmiére colonne 
        $resultat= $req3 ->fetch();
        if(!$resultat){
            //Affichage d'un message d'erreur si l'identifiant ou le motPasse est incorrecte
            echo"<script type='text/javascript'>document.location.replace('../view/login.php');
            alert('impossible de mettre à jour un utilisateur inconnu !!');</script>";
        }else{
            if($mdpUser==$cMdp){
                //if($con->getnMdp() == $con->getcMdp()){
                $sql="UPDATE utilisateur SET motPasse='$mdpUser' WHERE identifiant='$idUser'";
                $req=$connexion->prepare($sql);
                //execution de la rqt avec eregistrement de resulat de la variable $reponse
                $reponse=$req->execute(array('idUser'=>$idUser,'mdpUser'=>$mdpUser));
                if(!$reponse){
                    echo"<script type='text/javascript'>document.location.replace('../view/updateMdp.php?id=$id');
                    alert('Not Good ! ');</script>";
                }else{
                    self::resetModifMdp($idUser);
                    echo"<script type='text/javascript'>document.location.replace('../view/login.php');
                    alert('Modification effectuée !');</script>";    
                }
            }
            else{
                echo"<script type='text/javascript'>document.location.replace('../view/updateMdp.php?id=$id');
                    alert('Champs de vérification différent du champ de mot de passe.');</script>";
            }
        }
    }

    public static function verifMdp($mdpUser,$cMdp){
        if($mdpUser==$cMdp){
            return true;
        }
        else{
            echo"<script type='text/javascript'>document.location.replace('../view/updateMdp.php?id=$id');
                    alert('Champs de vérification différent du champ de mot de passe.');</script>";
        }
    }

    public static function verifExistId($IdUser){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql="SELECT * from utilisateur where identifiant like '".$IdUser."'";
        $req=$connexion->query($sql);
        $resultat=$req->fetch();
        if(!$resultat){
            echo"<script type='text/javascript'>document.location.replace('../view/login.php');
            alert('Utilisateur inconnu.');</script>";
        }
        else{
            return true;
        }
    }

    public static function verifDemandeModif($IdUser){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql="SELECT * from utilisateur where changeMdp like '".$IdUser."'";
        $req=$connexion->query($sql);
        $resultat=$req->fetch();
        if(!$resultat){
            echo"<script type='text/javascript'>document.location.replace('../view/login.php');
            alert('Demande de modification inexistante.');</script>";
        }
        else{
            return true; 
        }
    }

    public static function recupId($IdUser){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql='SELECT identifiant from utilisateur where changeMdp like "'.$IdUser.'"';
        $req=$connexion->query($sql);
        $resultat=$req->fetch();
        return $resultat['identifiant'];
    }



    public static function resetModifMdp($idUser){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $sql='UPDATE utilisateur set changeMdp=NULL where identifiant like "'.$idUser.'"';
        $req=$connexion->query($sql);
    }
    
    public static function createUrl($IdUser){
    $dbi = DbSingleton::getInstance();
    $connexion=$dbi->getConnection();
    $i=0;
    $str='';
    while($i<20){
        $a=rand(0,1);
        if($a==1){
            $b=rand(65,90);
        }
        else{
            $b=rand(97,122);
        }
        $str.=chr($b);
        $i++;
    }
    $sql='UPDATE utilisateur set changeMdp="'.$str.'" where identifiant like "'.$IdUser.'"';
    $req=$connexion->query($sql);
    $url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
    $url=substr_replace($url,'view/updateMdp.ph',-31,-1).'?id='.$str;
    return $url;
    }

    public static function envoyerEmail($IdUser,$url){
        $dbi = DbSingleton::getInstance();
        $connexion=$dbi->getConnection();
        $headers = 'From: webmaster@example.com' . "\r\n" .
        'Reply-To: webmaster@example.com' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
        
        
        $destinataires=$IdUser;
        
        $Sujet="mot de passe oublié";
        
        // type de contenu HTML
        $entetes = "Content-type: text/html; charset=utf-8\n";
        
        $message = '<p><img src="./assets/images/nortechLogo.jpg" alt="" /> </p>
        <P>Bonjour <p><br>
        
        <p>Nous avons recu une demande de modification de mot de passe pour le compte associé à cette adresse mail. Veuillez cliquer sur le lien ci dessous:</p>
        
        <a href="'.$url.'">'.$url.'</a>
        
        <p>Si vous n\'êtes pas à l\'origine de cette demande, ignorez cet e-mail, la sécurité de votre compte est préservée.<br><br>
        
        A très bientot sur NORTECH.</p>';
        
        mail($destinataires, $Sujet, $message, $entetes, $headers);
        
    }

    public static function verifCVJoin($erreur,$size,$maxSize,$extUpload,$extValides){
        if($erreur>0){
            echo "<script type='text/javascript'>
            alert('Erreur lors du transfert! Le CV n'étant pas obligatoire pour l'enregistrement de l'employé,
            c'est dorénavant l'employé qui devra mettre à jour son CV via l'espace personnel');
                </script>";
            return false;
        }
        else if($size>$maxSize){
            echo "<script type='text/javascript'>
            alert('Le Fichier est trop gros! Le CV n'étant pas obligatoire pour l'enregistrement de l'employé,
            c'est dorénavant l'employé qui devra mettre à jour son CV via l'espace personnel');
                </script>";
            return false;
        }
        else if(!in_array($extUpload,$extValides)){
            echo "<script type='text/javascript'>alert('Type de fichier incorrect! Seul les \"PDF\" sont admis! Le CV n'étant pas obligatoire pour l'enregistrement de l'employé,
             c'est dorénavant l'employé qui devra mettre à jour son CV via l'espace personnel');</script>";
            return false;
        }
        else{
            return true;
        }
    }

    public static function saveCV(Employe $newObject, $adrTmp){
        $nomF= $newObject->getnoEmp().'_'.$newObject->getNom().'_'.$newObject->getPrenom().'.pdf';
        $fichier="../../CV/$nomF";
        
        $test=move_uploaded_file($adrTmp,$fichier);
        if($test){
            return true;
        }
        else{

            echo "<script type='text/javascript'>alert('Erreur lors de l\'enregistrement. Le CV n'étant pas obligatoire pour l'enregistrement de l'employé,
            c'est dorénavant l'employé qui devra mettre à jour son CV via l'espace personnel');</script>";
            return false;
        }
    }

    public static function copyCVD(Employe $newObject){
        $nomD= $newObject->getnoEmp().'_'.$newObject->getNom().'_'.$newObject->getPrenom().'.pdf';
        $fichier="../../CV/CVManquant.pdf";
        $destination="../../CV/$nomD";
        if(self::checkActive($newObject)==1){
            $dbi = DbSingleton::getInstance();
            $connexion=$dbi->getConnection();
            $sql='SELECT * from employe where tel like "'.$newObject->getTel().'"';
            $req=$connexion->query($sql);
            $resultat=$req->fetch();
            $nomF=$resultat['noEmp'].'_'.$resultat['nom'].'_'.$resultat['prenom'].'.pdf';
            $fichier="../../CV/$nomF";
            rename($fichier,$destination);
        }
        else{
            copy($fichier,$destination);
        }
    }
}
?>