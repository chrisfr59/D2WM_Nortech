<?php
echo"<script type='text/javascript'>document.location.replace('POO/view/index.php');</script>";
?>